package Worker;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeDriver 
{
	public static void main(String[] args) {
		
		ApplicationContext ac=new ClassPathXmlApplicationContext("EmployeValues.xml");
																//inserting xml file path		
		Employe e=(Employe)ac.getBean("employe");
									//getting from id in xml file		
		System.out.println(e.getId()+" "+e.getName()+" "+e.getDesignation()+" "+e.getSalary());
		
	}
}

package StudentSetterMethod;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StudentSchoolDriver
{
	public static void main(String[] args) {

		ApplicationContext ac=new ClassPathXmlApplicationContext("StudentSchool.xml");
								//CPXAC shortcut
		School s=(School)ac.getBean("myschool");
		
		System.out.println(s.getLocation());
		System.out.println(s.getStudent().getName());
		System.out.println(s.getStudent().getAge());
	}

}

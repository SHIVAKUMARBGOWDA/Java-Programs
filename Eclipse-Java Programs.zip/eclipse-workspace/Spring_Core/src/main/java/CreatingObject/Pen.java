package CreatingObject;

public class Pen 
{
	public void write()
	{
		System.out.println("Pen is writting..........");
	}

}

package CreatingObject;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PenDriver
{
	public static void main(String[] args) 
	{
		ApplicationContext ac=new ClassPathXmlApplicationContext("SpringCore.xml");
		
		Pen p=(Pen)ac.getBean("pen");
		
		p.write();
	}

}

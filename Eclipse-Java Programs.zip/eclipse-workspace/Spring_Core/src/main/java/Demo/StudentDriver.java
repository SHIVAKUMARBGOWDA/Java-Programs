package Demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StudentDriver 
{
	public static void main(String[] args) 
	{	
		ApplicationContext ac=new ClassPathXmlApplicationContext("SpringCore.xml");
		
		Student s=(Student)ac.getBean("student"); //id name in SpringCore.xml file
		
		s.showDetails();
		//System.out.println(s.id+" "+s.name+" "+s.age+" "+s.phone);
	}
}

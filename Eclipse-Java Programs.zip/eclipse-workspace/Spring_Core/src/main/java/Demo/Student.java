package Demo;

public class Student 
{
	 int id=1;
	 String name="SHIVAKUMAR";
	 int age=23;
	 long phone=9110664616l;
	 
	 public void showDetails()
	 {
		 System.out.println("Student Details...");
		 System.out.println(id+" "+name+" "+age+" "+phone);
	 }
	

}

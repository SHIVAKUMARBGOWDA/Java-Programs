package EmployeCompanyConstructorMethod;

public class Company 
{
	private String location;
	Employe employe;
	
	public Company(String location, Employe employe) {
		super();
		this.location = location;
		this.employe = employe;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Employe getEmploye() {
		return employe;
	}
	public void setEmploye(Employe employe) {
		this.employe = employe;
	}
	

}

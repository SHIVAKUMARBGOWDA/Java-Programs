package EmployeCompanyConstructorMethod;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CompanyEmployeDriver 
{
	public static void main(String[] args) {
		
		ApplicationContext ac=new ClassPathXmlApplicationContext("CompanyEmploye.xml");
		
		Company c=(Company)ac.getBean("mycompany");
		System.out.println(c.getLocation());
		System.out.println(c.getEmploye().getName());
		System.out.println(c.getEmploye().getSalary());
		c.getEmploye().work();
	}
}

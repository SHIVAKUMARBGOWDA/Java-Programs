package ConstructorMethod;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CarDriver
{
	public static void main(String[] args) {
		
		ApplicationContext ac=new ClassPathXmlApplicationContext("Car.xml");
		
		Car c=(Car)ac.getBean("mycar");
		System.out.println(c.getBrand());
		
		c.getEngine().test();
	}

}

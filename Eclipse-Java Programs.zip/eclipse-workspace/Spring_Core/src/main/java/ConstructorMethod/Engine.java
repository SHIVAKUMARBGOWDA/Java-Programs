package ConstructorMethod;

public class Engine 
{
	public void test()
	{
		System.out.println("Engine is Working");
	}

}

package SetterMethod;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MobileDriver
{
	public static void main(String[] args) {
		
		ApplicationContext ac=new ClassPathXmlApplicationContext("MobileSim.xml");
		
		Mobile m=(Mobile)ac.getBean("mymobile");
		
		System.out.println(m.getBrand()+" "+m.getPrice());
		System.out.println(m.getSim().getProvider());
		System.out.println(m.getSim().getType());
		
		
	}

}

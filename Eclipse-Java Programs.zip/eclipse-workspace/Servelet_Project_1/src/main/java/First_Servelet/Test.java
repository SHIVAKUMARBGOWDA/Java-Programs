package First_Servelet;

import java.io.IOException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/first")
public class Test extends GenericServlet
{
	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		System.out.println("Hello......!!");
		
		String name=req.getParameter("myname");
		String age=req.getParameter("myage");
		
		System.out.println("Name is :"+name);
		System.out.println("Age is :"+age);
	}
}

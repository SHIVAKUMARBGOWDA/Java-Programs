package First_Servelet;

import java.io.IOException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/shiva")
public class Details extends GenericServlet
{
	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {

		String fname=req.getParameter("fnm");
		String lname=req.getParameter("lnm");
		String num=req.getParameter("ph");
		String dob=req.getParameter("dob");
				
		System.out.println("First Name : "+fname);
		System.out.println("Last Name: "+lname);
		System.out.println("Phone Number: "+num);
		System.out.println("DOB : "+dob);

	}
}

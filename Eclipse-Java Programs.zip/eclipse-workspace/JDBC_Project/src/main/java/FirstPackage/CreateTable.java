package FirstPackage;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CreateTable 
{
	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		//load and register driver
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		//establish the connection
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/company","root","root");
		
		//create statement
		Statement st=con.createStatement();
		
		//execute the query
		st.execute("create table employee(id integer, name varchar(20),salary integer)");
		
		//close the connection
		con.close();
		
	}

}

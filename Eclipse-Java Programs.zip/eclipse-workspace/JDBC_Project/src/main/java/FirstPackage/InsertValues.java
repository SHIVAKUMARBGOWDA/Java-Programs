package FirstPackage;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class InsertValues 
{
	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/company","root","root");
		
		Statement st=con.createStatement();
		
		st.execute("insert into employee values(11,'SHIVAKUMAR',40000)");
		st.execute("insert into employee values(12,'SomaShekar',40000)");
		st.execute("insert into employee values(13,'PRAJWAL',45000)");

		
		
		con.close();
	}

}

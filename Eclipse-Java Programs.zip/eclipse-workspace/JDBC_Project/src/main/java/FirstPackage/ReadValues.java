package FirstPackage;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ReadValues 
{
	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/company","root","root");
		
		Statement st=con.createStatement();
		
		ResultSet rs=st.executeQuery("select * from employee");
		
		while(rs.next())
		{
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3));
		}
		
		System.out.println();
		
		ResultSet rs1=st.executeQuery("select id,salary from employee");
		
		while(rs1.next())
		{
			System.out.println(rs1.getInt(1)+" "+rs1.getInt(2));
		}
			
		System.out.println();
		
		ResultSet res=st.executeQuery("select name from employee where id=11");
		while(res.next())
		{
			System.out.println(res.getString(1));
		}
	}
}

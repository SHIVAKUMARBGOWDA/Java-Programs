package FirstPackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class EstablishConnection 
{
	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		//load and register the driver
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		//Establish connection
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","root");
		
		//Create Statement using Statement interface
		Statement st=con.createStatement();
		
		//Execute the query
		st.execute("create database company"); //return type is boolean
		System.out.println("database created...");
		
		//Close the connection
		con.close();		
	}
}

package Demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/cookie")
public class FirstServlet extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		//fetching data
		String name=req.getParameter("myname");
		String password=req.getParameter("psw");
		
		resp.setContentType("text/html");
		//Displaying data
		PrintWriter pw=resp.getWriter();
		
		pw.print("Name= "+name+"<br> Password=  "+password);
		
		Cookie ck=new Cookie("uname",name);
		
		resp.addCookie(ck);
		
		pw.print("<form action='second' method=post>");
		pw.print("<input type='submit' value='Click here'>");
		pw.print("</form>");
		
}
}

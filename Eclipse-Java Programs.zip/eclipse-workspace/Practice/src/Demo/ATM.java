package Demo;

import java.util.*;

public class ATM
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Amount:");
		int amt=sc.nextInt();
		int []rupees= {50,20,10};
		int []count= {0,0,0};
		for(int i=0;i<rupees.length;i++)
		{
			if(rupees[i]<amt||rupees[i]==amt)
			{
				count[i]=amt/rupees[i];
				amt=amt%rupees[i];
			}
		}
		for(int i=0;i<count.length;i++)
		{
			if(count[i]!=0)
			{
				System.out.println(count[i]+"*"+rupees[i]+"="+(rupees[i]*count[i]));
			}
		}
	}
}

package Demo;

import java.util.Scanner;

public class AlphaNumericSum 
{
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		int sum=0;
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)>='1'&&s.charAt(i)<='9')
				
			{
				sum+=Character.getNumericValue(s.charAt(i));
			}
		}
		System.out.println(sum);
	}

}

package Demo;

public class SecondHighestNumber 
{
	public static void main(String[] args) {
		
		int a[]= {10,20,45,90,60,87,80,150};
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					int temp=a[j];
					a[j]=a[i];
					a[i]=temp;
				}
			}
		}
		System.out.println(a[a.length-2]);
	}

}

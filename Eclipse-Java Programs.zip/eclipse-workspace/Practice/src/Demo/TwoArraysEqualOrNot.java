package Demo;

import java.util.*;
import java.util.Arrays;
import java.util.Scanner;

public class TwoArraysEqualOrNot
{
	public static boolean areEqual(int a[],int b[])
	{
		int m=a.length;
		int n=b.length;
		Arrays.sort(a);
		Arrays.sort(b);
		if(m!=n)
		{
			
			return false;
		}
		return true;
		
	}
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Array Elements");
		int a[]=new int[5];
		int b[]=new int[6];
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			b[i]=sc.nextInt();
		}
		Arrays.sort(a);
		Arrays.sort(b);
		boolean c=areEqual(a,b);
		
		if(areEqual(a, b) )
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
	}
	}



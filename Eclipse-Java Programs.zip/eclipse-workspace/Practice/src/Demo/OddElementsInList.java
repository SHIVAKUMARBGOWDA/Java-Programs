package Demo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class OddElementsInList 
{
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Size");
		int n=sc.nextInt();
		List<Integer> a=new ArrayList<>();
		for(int i=0;i<n;i++)
		{
			a.add(sc.nextInt());
		}
		if(isListOdd(a))
			System.out.println("Contains");
		else
			System.out.println("Not Contains");		
	}

	public static boolean isListOdd(List<Integer> a) {
		for(int i:a)
		{
			if(i%2==0)
				return false;
		}
		return true;
	}

}

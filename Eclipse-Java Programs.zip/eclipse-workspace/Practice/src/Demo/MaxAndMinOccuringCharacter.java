package Demo;

import java.util.Scanner;

public class MaxAndMinOccuringCharacter 
{
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		char c[]=s.toCharArray();
		int a[]=new int[c.length];
		for(int i=0;i<c.length;i++)
		{
			a[i]=1;
			for(int j=i+1;j<c.length;j++)
			{
				if(c[i]==c[j]&&c[j]!='0'&&c[j]!=' ')
				{
					a[i]++;
					c[j]='0';
				}
			}
		}
				int max=a[0];
				int min=a[0];
				int i1=0;
				int i2=0;
				for(int i=0;i<a.length;i++)
				{
					if(max<a[i])
					{
						max=a[i];
						i1=i;
					}
					if(min>a[i])
					{
						min=a[i];
						i2=i;
					}
				}
				System.out.println("Max occuring : "+c[i1]+" & "+max+" times");
				System.out.println("Min occuring : "+c[i2]+" & "+min+" times");

	}

}

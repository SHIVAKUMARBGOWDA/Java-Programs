package Demo;

import java.util.Scanner;

public class StringReverse 
{
	public static String reverse(String s)
	{
		String s1="";
		for(int i=s.length()-1;i>=0;i--)
		{
			s1+=s.charAt(i);
		}
		return s1;
		
	}
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		String a=reverse(s);
		System.out.println(a);
	}

}

package OneToOne;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class BookController
{
	public static void main(String[] args) {
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("shiva");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transaction=manager.getTransaction();
		
		 Book b=new Book();
		 b.setId(1);
		 b.setTitle("Java");
		 b.setPublishdate(new Date());
		 
		 Author a=new Author();
		 a.setId(1);
		 a.setName("James Gosgline");
		 a.setEmail("james@gmail.com");
		 
		 b.setAuthor(a);
		 
		 transaction.begin();
		 manager.persist(b);
		 manager.persist(a);
		 transaction.commit();
		 
	}

}

package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String firstName = req.getParameter("firstName");
        String lastName = req.getParameter("lastName");
        String emailId = req.getParameter("emailId");
        String password = req.getParameter("password");

        resp.setContentType("text/html");
        PrintWriter printWriter = resp.getWriter();
   
        printWriter.print("<h1 style=background-color:yellow;color:blue;border:2px solid> Student Resistration Form Data </h1>");
        printWriter.print("<p> FirstName :: " + firstName + "</p>");
        printWriter.print("<p> LastName :: " + lastName + "</p>");
        printWriter.print("<p> Email Id :: " + emailId + "</p>");
        printWriter.print("<p> Password :: " + password + "</p>");
       

        printWriter.close();

        System.out.println("FirstName :: " + firstName);
        System.out.println("LastName :: " + lastName);
        System.out.println("EmailId :: " + emailId);
        System.out.println("Password :: " + password);
    }
}

package CONTROLLER;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.StudentDAO;
import DTO.Student;

@WebServlet("/std")
public class InsertController extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//fetching the data from request
		String id=req.getParameter("id");
		String name=req.getParameter("myname");
		String age=req.getParameter("myage");
		String phone=req.getParameter("ph");
		String address=req.getParameter("adr");
		String gender=req.getParameter("gen");
		String college=req.getParameter("clg");
		
		//creating user object
		Student s=new Student();
		
		//setting values to user object
		s.setId(Integer.parseInt(id));
		s.setName(name);
		s.setAge(Integer.parseInt(age));
		s.setPhone_no(Integer.parseInt(phone));
		s.setAddress(address);
		s.setGender(gender);	
		s.setCollege(college);
		
		StudentDAO dao=new StudentDAO();
		
		try
		{
			dao.insertValues(s);
		}
		catch(Exception e)
		{
			System.out.println("Exception handled....");
		}
	}
}

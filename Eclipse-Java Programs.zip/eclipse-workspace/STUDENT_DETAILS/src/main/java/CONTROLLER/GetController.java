package CONTROLLER;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.StudentDAO;
import DTO.Student;

@WebServlet("/welcome")
public class GetController extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String id=req.getParameter("id");
		
		StudentDAO dao=new StudentDAO();
		try
		{
			Student s=dao.getUser(Integer.parseInt(id));
			PrintWriter pw=resp.getWriter();
			resp.setContentType("text/html");
			
			pw.println("<p>"+"WELCOME"+"</p>");
			
			pw.println("<p> ID: "+s.getId()+"</p>");
			pw.println("<p> NAME: "+s.getName()+"</p>");
			pw.println("<p> AGE: "+s.getAge()+"</p>");
			pw.println("<p> PHONE-NO: "+s.getPhone_no()+"</p>");
			pw.println("<p> Address: "+s.getAddress()+"</p>");
			pw.println("<p> GENDER: "+s.getGender()+"</p>");
			pw.println("<p> COLLEGE: "+s.getCollege()+"</p>");
			
			
		}
		catch(Exception e)
		{	
			System.out.println("Exception Handled....");
		}		
		
	}
}



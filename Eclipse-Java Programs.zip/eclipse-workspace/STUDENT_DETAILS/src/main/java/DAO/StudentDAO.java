package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import DTO.Student;


public class StudentDAO 
{
	public Connection getConnection() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","root");
		return con;		
	}
	
	public void insertValues(Student s) throws ClassNotFoundException, SQLException
	{
		PreparedStatement ps=getConnection().prepareStatement("insert into stdb values(?,?,?,?,?,?,?)");
		
		//fetching the data from Student object
		int id=s.getId();
		String name=s.getName();
		int age=s.getAge();
		long phoneno=s.getPhone_no();
		
		String address=s.getAddress();
		String gender=s.getGender();
		String college=s.getCollege();
		
		//set values to query
		ps.setLong(1, phoneno);
		ps.setString(2, name);
		ps.setInt(3, age);
		ps.setLong(4, id);
		ps.setString(5, address);
		ps.setString(6, gender);
		ps.setString(7, college);
		
		//execute the query
		ps.execute();
	}
	
	public Student getUser(int id) throws ClassNotFoundException, SQLException
	{
		PreparedStatement ps=getConnection().prepareStatement("select * from stdb where id=?");
		ps.setInt(1, id);
		
		ResultSet rs=ps.executeQuery();
		
		Student s=new Student();
		while(rs.next())
		{
			s.setId(rs.getInt(1));
			s.setName(rs.getString(2));
			s.setAge(rs.getInt(3));
			s.setPhone_no(rs.getInt(4));
			s.setAddress(rs.getString(5));
			s.setGender(rs.getString(6));
			s.setCollege(rs.getString(7));
		}
		return s;
		
	}
}

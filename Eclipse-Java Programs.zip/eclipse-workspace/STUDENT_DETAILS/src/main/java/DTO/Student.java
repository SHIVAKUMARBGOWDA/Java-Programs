package DTO;

public class Student 
{
	private int id;
	private String name;
	private int age;
	private int phone_no;
	private String address;
	private String gender;
	private String college;
	
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public int getPhone_no() {
		return phone_no;
	}
	public String getAddress() {
		return address;
	}
	public String getGender() {
		return gender;
	}
	public String getCollege() {
		return college;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setPhone_no(int phone_no) {
		this.phone_no = phone_no;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public void setCollege(String college) {
		this.college = college;
	}
	

}

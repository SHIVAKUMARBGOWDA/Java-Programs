package Programs;

import java.util.Scanner;

public class NeonNumber
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		int sum=0;
		int sqr=num*num;
		while(sqr>0)
		{
			int last=sqr%10;
			sum+=last;
			sqr/=10;
		}
		if(sum==num)
			System.out.println("Neon Number");
		else
			System.out.println("Not a Neon Number");
	}

}

package Programs;

import java.util.Scanner;

public class EligibleForVote_Or_Not 
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int age=sc.nextInt();
		if(age>=18)
		{
		System.out.println("person is eligible for vote");
		}
		else
			{
			System.out.println("person is not eligible for vote");
		}
	}

}

package Programs;

import java.util.Iterator;
import java.util.Scanner;

public class String_Calculator
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Numbers");
		String a=sc.next();
		
		System.out.println(a);
		String b[]=a.split("[0-infinity]");
		String c[]=a.split("[*+-/]");
		int ag=Integer.parseInt(c[0]);
		for(int i=1;i<c.length;i++)
		{
			if(b[i].equals("+"))
				ag+=Integer.parseInt(c[i]);
			else if(b[i].equals("-"))
				ag-=Integer.parseInt(c[i]);
			else if(b[i].equals("*"))
				ag*=Integer.parseInt(c[i]);
			else
				ag/=Integer.parseInt(c[i]);
			
		}
		System.out.println(ag);
	}
}

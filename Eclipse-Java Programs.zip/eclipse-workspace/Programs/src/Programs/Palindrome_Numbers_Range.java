package Programs;

import java.util.Scanner;

public class Palindrome_Numbers_Range 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the range of m: ");
		int m=sc.nextInt();
		System.out.println("Enter the range of n:");
		int n=sc.nextInt();
		for(int i=m;i<=n;i++)
		{
			int num=i;
			int temp=i; 
			int rev=0;
			while(num>0)
			{
				int rem=num%10;
				rev=rev*10+rem;
				num=num/10;
			}
			if(temp==rev)
			System.out.println(rev);
		}		
	}
}

package Programs;

import java.util.Scanner;

public class ProductOfDigits 
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		int count=0;
		int pro=1;
		while(num>0)
		{
			int last=num%10;
			pro=pro*last;
			num/=10;
		}
		System.out.println(pro);
	}


}

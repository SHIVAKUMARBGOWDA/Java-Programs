package Programs;

import java.util.Scanner;

public class ProductOfEachNumber 
{
	public static void main(String[] args) {
		System.out.println("Enter the Number");
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		int pro=1;
		while (num!=0)
		{
			int rem=num%10;
			num=num/10;
			pro=pro*rem;
		}
				System.out.println("product="+pro);

	}

}

package Programs;

import java.util.Scanner;

public class SpyNumber 
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		int sum=0;
		int pro=1;
		while(num>0)
		{
			int last=num%10;
			pro=pro*last;
			sum+=last;
			num/=10;
		}
		if(sum==pro)
		System.out.println("Spy Number");
		else
			System.out.println("Not Spy Number");
	}


}

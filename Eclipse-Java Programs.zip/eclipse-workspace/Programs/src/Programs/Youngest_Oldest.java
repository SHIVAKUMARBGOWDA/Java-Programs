package Programs;

import java.util.Scanner;

public class Youngest_Oldest 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);	
		int age1=sc.nextInt();
		int age2=sc.nextInt();
		if(age1<age2)
		{
		System.out.println(age1+ " is youngest");
		System.out.println(age2+ " is oldest");
		}
		else if (age1>age2)
		{
			System.out.println(age1+ " is oldest");
			System.out.println(age2+ " is youngest");
		}
		else
		{
			System.out.println("Both are of same age");
		}
	}
}

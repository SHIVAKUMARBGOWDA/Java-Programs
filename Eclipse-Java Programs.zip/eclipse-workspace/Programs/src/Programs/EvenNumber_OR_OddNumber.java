package Programs;

import java.util.Scanner;

public class EvenNumber_OR_OddNumber
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the Number :");
		int num=sc.nextInt();
			if(num%2==0)
				System.out.println("Even Number");
			else
				System.out.println("Odd Number");
		}	
	}



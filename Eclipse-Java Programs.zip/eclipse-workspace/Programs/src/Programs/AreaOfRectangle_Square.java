package Programs;

import java.util.Scanner;

public class AreaOfRectangle_Square
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int length=sc.nextInt();
		int width=sc.nextInt();
		int a=length*width;
		int b=width*width;
		System.out.println("Area of Rectangle= "+a);
		System.out.println("Area of Square= "+b);
	}

}

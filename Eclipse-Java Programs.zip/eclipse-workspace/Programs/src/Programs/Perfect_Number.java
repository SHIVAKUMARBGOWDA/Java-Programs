package Programs;

import java.util.Scanner;
public class Perfect_Number 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the range of m :");
		int m=sc.nextInt();
		System.out.println("Enter the range of n :");
		int n=sc.nextInt();
		for(int i=m;i<=n;i++)
		{
			int num=i;
			int sum=0;
			for(int j=1;j<=num/2;j++)
			{
				if(num%j==0)
					sum=sum+j;
			}
			if(num==sum)
				System.out.print(num+" ");				
		}		
	}
}

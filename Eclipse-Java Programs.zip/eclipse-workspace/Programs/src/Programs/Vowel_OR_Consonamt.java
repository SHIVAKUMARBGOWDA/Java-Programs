package Programs;

import java.util.Scanner;

public class Vowel_OR_Consonamt 
{
	public static void main(String[] args) 
	{
	Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Character:");
		char c=sc.next().charAt(0);
		if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u')
			System.out.println("vowel");
		else
			System.out.println("consonant");
		
	}

}

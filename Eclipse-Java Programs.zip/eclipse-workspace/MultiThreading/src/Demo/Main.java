package Demo;

class ThreadLifeCycle implements Runnable
{

	@Override
	public void run() 
	{
		System.out.println("Thread is Running");
		System.out.println("Thread a state is "+Thread.currentThread());
		try
		{
			Thread.sleep(2000);
		}
		catch (InterruptedException e) {}
		System.out.println("Thread b state is "+Main.t1.getState());
	}
	
}
public class Main implements Runnable
{
	public static Thread t1;
	public static void main(String[] args) 
	{
		Main m=new Main();
		t1=new Thread(m);
		System.out.println("Thread c state is "+t1.getState());
		t1.start();
	}
	@Override
	public void run()
	{
		ThreadLifeCycle tlc=new ThreadLifeCycle();
		Thread t2=new Thread(tlc);
		t2.start();
		System.out.println("Thread d is in "+Thread.currentThread());
		try
		{
			t2.join();
			System.out.println("Thread e state is "+Thread.currentThread());
		}
		catch (InterruptedException e) {
			// TODO: handle exception
		}
	}
}

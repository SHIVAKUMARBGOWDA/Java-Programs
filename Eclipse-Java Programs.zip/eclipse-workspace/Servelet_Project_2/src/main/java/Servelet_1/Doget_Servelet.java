package Servelet_1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/first")
public class Doget_Servelet extends HttpServlet
{
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//fetching data from request
		String name=req.getParameter("myname");
		
		//setting the response content type to text or html
		resp.setContentType("text/html");
		
		//creating print writer object
		PrintWriter pw=resp.getWriter();
		
		//Printing data on web page using print method of PrintWriter class
		pw.print("<h1 style=background-color:yellow>Welcome....."+name+"<h1>");
		System.out.println(name);
	}
}

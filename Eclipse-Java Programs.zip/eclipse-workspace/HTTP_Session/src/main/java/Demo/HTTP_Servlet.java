package Demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/save")
public class HTTP_Servlet extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//Fetching data 
		String name=req.getParameter("myname");
		String password=req.getParameter("psw");
		
		//Creating session object
		HttpSession session=req.getSession();
		
		//Setting user data into session object
		session.setAttribute("uname", name);
		session.setAttribute("upsw", password);
		
		resp.setContentType("text/html");
		//Printing data
		PrintWriter pw=resp.getWriter();
		
		pw.print("<form action='test'>");
		pw.print("<input type='submit' value='Enter Here'>"+"<br>");
		pw.print("</form>");
		
	}
}

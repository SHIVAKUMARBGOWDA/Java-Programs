//Print smallest and biggest possible palindrome word in a given string
package StringPrograms;

import java.util.Scanner;

public class String18 
{
	public static int checkPalindrome(String s) 
	{
		int count=1;
		for (int i=0;i<=s.length()/2;i++)
		{
			if (s.charAt(i)!=s.charAt(s.length()-1-i))
			{
				count=0;
				break;
			}
		}
		if(count==0)
			return count;
		else	
		return s.length();
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		String s1[]=s.split(" ");
		int[]a=new int[s1.length];
		for(int i=0;i<s1.length;i++)
		{
			a[i]=checkPalindrome(s1[i]);
		}
		int max=a[0];
		int min=a[0];
		int max_index=0;
		int min_index=0;
		for (int i=1;i<a.length;i++)
		{
			if(a[i]!=0)
			{
				if(max<a[i])
				{
					max=a[i];
					max_index=i;
				}
				if(min>a[i])
				{
					min=a[i];
					min_index=i;
				}
			}
		}
		System.out.println("Biggest palindrome is : "+s1[max_index]);
		System.out.println("Smallest palindrome is : "+s1[min_index]);
	}
}

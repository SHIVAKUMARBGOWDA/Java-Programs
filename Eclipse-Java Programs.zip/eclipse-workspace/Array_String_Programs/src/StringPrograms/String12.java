//Count of Special symbols,Lowercase,Uppercase and Digits in a String
package StringPrograms;

import java.util.Scanner;

public class String12 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		int c1=0,c2=0,c3=0,c4=0;
		for (int i=0;i<s.length();i++)
		{
			char a=s.charAt(i);
			if(a==','||a=='.'||a=='-'||a==';'||a=='?'||a=='&'||a==':'||a=='!')
			{
				c1++;
			}
			if(a>='a' && a<='z')
			{
				c2++;
			}
			if(a>='A' && a<='Z')
			{
				c3++;
			}
			if(a>='1' && a<='9')
			{
				c4++;
			}
		}
		System.out.println("Special Symbols count : "+c1);
		System.out.println("Lowercase characters : "+c2);
		System.out.println("Uppercase characters : "+c3);
		System.out.println("Digits count : "+c4);

	}

}

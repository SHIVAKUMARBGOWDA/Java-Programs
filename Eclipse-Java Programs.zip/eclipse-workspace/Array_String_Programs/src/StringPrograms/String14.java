//LowerCase to UpperCase
package StringPrograms;

import java.util.Scanner;

public class String14 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		char[] c=s.toCharArray();
		for (int i=0;i<c.length;i++)
		{
			if (c[i]>='a' && c[i]<='z')
			{
				c[i]=(char)((int)c[i]-32);
			}
		}
		for (int i=0;i<c.length;i++)
		System.out.print(c[i]);
		
	}

}

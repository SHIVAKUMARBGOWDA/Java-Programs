//Minimum and Maximum occuring characters in a String
package StringPrograms;

import java.util.Scanner;

public class String10 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String value");
		String s=sc.nextLine();
		char[] c=s.toCharArray();
		int[] a=new int[c.length];
		for (int i=0;i<c.length;i++)
		{
			a[i]=1;
			for (int j=i+1;j<c.length;j++)
			{
				if(c[i]==c[j] && c[j]!=' ' && c[j]!='0')
				{
					a[i]++;
					c[j]='0';
				}
			}
		}
		int max=a[0];
		int min=a[0];
		int index1=0;
		int index2=0;
		
		for (int i=1;i<a.length;i++)
		{
			if (max<a[i])
			{
				max=a[i];
				index1=i;
			}
			if (min>a[i])
			{
				min=a[i];
				index2=i;
			}
		}
		System.out.println("Maximum occuring character is "+ c[index1]+" & "+max+" times");
		System.out.println("Minimum occuring character is "+ c[index2]+" & "+min+" times");
	}
}

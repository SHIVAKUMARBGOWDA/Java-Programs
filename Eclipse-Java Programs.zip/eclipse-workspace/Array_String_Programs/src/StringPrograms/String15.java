//Duplicate Characters in String
package StringPrograms;

import java.util.Scanner;

public class String15 
{
	public static char[] duplicateCharacters(String s)
	{
		char[] c=s.toCharArray();
		int[] a=new int[c.length];
		
		for (int i=0;i<c.length;i++)
		{
			a[i]=1;
			for (int j=i+1;j<c.length;j++)
			{
				if (c[i]==c[j] && c[j]!=0 && c[j]!=' ')
				{
					a[i]++;
					c[j]=0;
				}
			}
		}
		int count=0;
		for (int i=0;i<c.length;i++)
		{
			if (a[i]>1)
			{
				count++;
			}
		}
		char[] c1=new char[count];
		int temp=0;
		for (int i=0;i<c.length;i++)
		{
			if (a[i]>1)
			{
				c1[temp++]=c[i];			
			}
		}
		return c1;
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		char[] c=duplicateCharacters(s);
		
		for (int i=0;i<c.length;i++)
		{
			System.out.print(c[i]+" ");
		}
	}
}

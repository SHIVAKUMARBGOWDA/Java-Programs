//Sum of Numbers in Alpha-Numeric value
package StringPrograms;

import java.util.Scanner;

public class String11 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Alpha-Numeric Value");
		String s=sc.nextLine();
		int sum=0;
		for (int i=0;i<s.length();i++)
		{
			
			if(s.charAt(i)>='1'&&s.charAt(i)<='9')
			{
				sum=sum+Character.getNumericValue(s.charAt(i));
			}
		}
		System.out.println(sum);
	}
}

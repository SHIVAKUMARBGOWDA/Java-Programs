//Frequency of characters
package StringPrograms;

import java.util.Scanner;

public class String17 
{
	public static char[] characterArray(String s)
	{
		char[] c=s.toCharArray();
		for (int i=0;i<c.length;i++)
		{
			for (int j=i+1;j<c.length;j++)
			{
				if(c[i]==c[j] &&c[j]!='0')
				{
					c[j]='0';
				}
			}
		}
		
		return c;
}
	public static int[] frequency(String s)
	{
		char[] c=s.toCharArray();
		int[] a=new int[c.length];
		
		for (int i=0;i<c.length;i++)
		{
			a[i]=1;
			for (int j=i+1;j<c.length;j++)
			{
				if(c[i]==c[j] &&c[j]!='0')
				{
					a[i]++;
					c[j]='0';
				}
			}
		}
		
		return a;
	}
		
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		char[] c=characterArray(s);
		int[] a=frequency(s);
	
		for(int i=0;i<s.length();i++)
		{
			if(c[i]!='0')
			{
				System.out.println(c[i]+" occuring "+a[i]+" times");
			}
		}
	}
}

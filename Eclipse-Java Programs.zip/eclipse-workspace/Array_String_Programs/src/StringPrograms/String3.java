//Total no.of punctuation characters in a String
package StringPrograms;

import java.util.Scanner;

public class String3 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String: ");
		String s=sc.nextLine();
		int count=0;
		for(int i=0;i<s.length();i++)
		{
			char a=s.charAt(i);
			if(a==','||a=='.'||a=='-'||a==';'||a=='?'||a=='/'||a==':'||a=='!')
			{
				count++;
			}
		}
		System.out.println("No.of Punctuations: "+count);
	}
}

	

//Duplicate words in String
package StringPrograms;

import java.util.Scanner;

public class String16 
{
	public static String[] duplicateWords(String s)
	{
		String[] s1=s.split(" ");
		int[] a=new int[s1.length];
		
		for (int i=0;i<s1.length;i++)
		{
			a[i]=1;
			for (int j=i+1;j<s1.length;j++)
			{
				if (s1[i].equalsIgnoreCase(s1[j]) && s1[j]!="0")
				{
					a[i]++;
					s1[j]="0";
				}
			}
		}
		int count=0;
		for (int i=0;i<a.length;i++)
		{
			if(a[i]>1)
				count++;
		}
		String s2[]=new String[count];
		int temp=0;
		for (int i=0;i<a.length;i++)
		{
			if(a[i]>1)
			{
				s2[temp++]=s1[i];
			}
		}
		return s2;
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		String[] s1=duplicateWords(s);
		
		for (int i=0;i<s1.length;i++)
		{
			
			System.out.print(s1[i]+" ");
		}	
	}
}
//Big black bug is sitting on Big black nose of big black dog

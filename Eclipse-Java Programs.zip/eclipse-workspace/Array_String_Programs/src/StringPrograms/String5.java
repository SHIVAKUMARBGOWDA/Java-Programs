//Remove all the white spaces in String
package StringPrograms;

import java.util.Scanner;

public class String5
{
	public static void main(String[] args)
	{
		System.out.println("Enter the String Value");
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		String s1="";
		
		for (int i=0;i<s.length();i++)
		{
			if (s.charAt(i)!=' ')
				s1=s1+s.charAt(i);
		}
		System.out.println(s1);
		
	}

}

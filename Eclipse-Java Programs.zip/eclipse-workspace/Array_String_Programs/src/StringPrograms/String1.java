//Count the no.of characters in String
package StringPrograms;

import java.util.Scanner;

public class String1 
{
	public static void main(String[] args)
	{
		System.out.println("Enter the String value");
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		int count=0;
		for (int i=0;i<s.length();i++)
		{
			if(s.charAt(i)!=' ')
				count++;
		}
		
		System.out.println(count);
	}

}

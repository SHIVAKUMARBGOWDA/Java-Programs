//Count the total number of vowels and consonants in a String
package StringPrograms;

import java.util.Scanner;

public class String4
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String :");
		String s=sc.nextLine();
		s=s.toLowerCase();
		int count=0,count1=0;
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)=='a'||s.charAt(i)=='e'||s.charAt(i)=='i'||
					s.charAt(i)=='o'||s.charAt(i)=='u')
			{
				count++;
			}
			else if(s.charAt(i)>='a'&&s.charAt(i)<='z')
			{
				
				count1++;
			}	
		}
		System.out.println("No.of Vowels: "+count);
		System.out.println("No.of Consonants: "+count1);
	}

}

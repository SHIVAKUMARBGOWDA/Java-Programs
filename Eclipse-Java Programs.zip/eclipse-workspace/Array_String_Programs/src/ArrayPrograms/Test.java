package ArrayPrograms;
//class A{}
//class B extends A{}
//class C extends B{}

// 3.
//class X
//{
//	void method(int a)
//	{
//		System.out.println("ONE");
//	}
//	void method(double d)
//	{
//		System.out.println("TWO");
//	}
//}
//class Y extends X
//{
//	void method (double d)
//	{
//		System.out.println("THREE");
//	}
//}
public class Test
{
	public static void main(String[] args) 
	{
		A a1=new A();
	}
}
class A 
{
	int x=99;
	static int y=88;
	static A a1=new A();
	static
	{
		System.out.println("SIB-1");
	}
	{
		System.out.println("11B-1");
	}
	int i=77;
	static int j=66;
	static
	{
		System.out.println("SIB-2");
	}
	{
		System.out.println("11B-2");
	}
}
//class A
//{
//	static A a1=new A();
//	void A(int i,int j)
//	{
//		System.out.println(i+j);
//	}
////	int k;
//	boolean isTrue;
//	static int p;
//	public void print()
//	{
//		System.out.println(k);
//		System.out.println(isTrue);
//		System.out.println(p);
//	}


//	1.
	
//	static void method(A a)
//	{
//		System.out.println("ONE");
//	}
//	static void method(B b)
//	{
//		System.out.println("TWO");
//	}
//	static void method(Object o)
//	{
//		System.out.println("THREE");
//	}
//	public static void main(String[] args) 
//	{
//		C c=new C();
//		method(c);
//		
//	}
	
//	2.
	
//	void method(int a)
//	{
//		System.out.println("1");
//	}
//	void method( int[] a)
//	{
//		System.out.println("2");
//	}
//	public static void main(String[] args) {
//		Test t=new Test();
//		t.method(10);
//	}
	


//Program to copy all the elements of one Array into another Array
package ArrayPrograms;

import java.util.Scanner;

public class Array5 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Size");
		int size=sc.nextInt();
		System.out.println("Enter the Elements");
		int a[]=new int[size];
		int b[]=new int[size];
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			b[i]=a[i];
		}
		System.out.print("Elements of array 1 is : ");
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}
		System.out.println();
		System.out.print("Elements of array 2 is : ");
		for(int i=0;i<b.length;i++)
		{
			System.out.print(b[i]+" ");
		}	
	}
}

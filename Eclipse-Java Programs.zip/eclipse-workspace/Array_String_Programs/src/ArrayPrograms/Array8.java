//Array elements in Ascending Order
package ArrayPrograms;

import java.util.Scanner;

public class Array8 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int size=sc.nextInt();
		int[] a=new int[size];
		for (int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.print("Array before sorting : ");
		
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+ " ");
		}
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
				int temp=a[j];
				a[j]=a[i];
				a[i]=temp;
				}
			}
		}
		System.out.println();
		System.out.print("Array after Sorting : ");
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}
	}
}

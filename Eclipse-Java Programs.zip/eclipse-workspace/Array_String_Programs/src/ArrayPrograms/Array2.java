//Program to print the sum of all the elements of an Array
package ArrayPrograms;

import java.util.Scanner;

public class Array2 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Size");
		int size=sc.nextInt();
		System.out.println("Enter the Elements");
		int a[]=new int[size];
		int sum=0;
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			sum=sum+a[i];
		}
		System.out.println("Sum of all the elements is : "+sum);
	}

}

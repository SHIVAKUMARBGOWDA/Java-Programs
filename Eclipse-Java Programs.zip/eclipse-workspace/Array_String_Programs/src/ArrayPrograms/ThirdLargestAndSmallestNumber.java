//Third largest and smallest number 
package ArrayPrograms;

import java.util.Scanner;

public class ThirdLargestAndSmallestNumber 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int size=sc.nextInt();
		int a[]=new int[size];
		int b[]=new int[size];
		int temp;
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			 b[i]=a[i];
		}
		
		//3rd largest number
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					temp=a[j];
					a[j]=a[i];
					a[i]=temp;
				}
			}
		}
		//3rd smallest number
		for(int i=0;i<b.length;i++)
		{
			for(int j=i+1;j<b.length;j++)
			{
				if(b[i]<b[j])
				{
					temp=b[j];
					b[j]=b[i];
					b[i]=temp;
				}
			}
		}
		System.out.println("3rd largest number: "+a[a.length-3]);		
		System.out.println("3rd smallest number : "+b[a.length-3]);
	}
}

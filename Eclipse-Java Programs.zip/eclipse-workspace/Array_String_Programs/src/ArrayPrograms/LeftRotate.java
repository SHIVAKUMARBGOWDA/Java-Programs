package ArrayPrograms;

import java.util.Scanner;

public class LeftRotate 
{
	public static int[] leftRotate(int a[])
	{
		int temp=a[0];
		for(int i=1;i<a.length;i++)
		{
			a[i-1]=a[1];
		}
		a[a.length-1]=temp;	
		return a;	
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int size=sc.nextInt();
		int a[]=new int[size];
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		a=leftRotate(a);
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}
	}
}

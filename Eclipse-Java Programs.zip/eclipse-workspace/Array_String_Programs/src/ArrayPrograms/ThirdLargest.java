package ArrayPrograms;

import java.util.Scanner;

public class ThirdLargest 
{
	public static void duplicatValues(int[] a)
	{
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]!=0&&a[i]==a[j]&&a[j]!=0)
				{
					a[j]=0;
				}				
			}
		}
		int count=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==0)
				count++;
		}
		int b[]=new int[a.length-count];
		int k=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]!=0)
				b[k++]=a[i];			
		}		
		System.out.println("Third largest Number is: "+b[b.length-3]);		
	}
	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int size=sc.nextInt();
		int a[]=new int[size];
		
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		duplicatValues(a);		
	}
}

//2nd largest number in an Array
package ArrayPrograms;

import java.util.Scanner;

public class Array13 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int size=sc.nextInt();
		int[]a=new int[size];
		
		for (int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		int count=0;
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]==a[j] &&a[j]!=0)
				{
					count++;
					a[j]=0;
				}
			}
		}
		int[] b=new int[a.length-count];
		int temp=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]!=0)
				b[temp++]=a[i];
		}
		System.out.println(b[b.length-2]);
	}
}

//Program to print the number of elements present in an Array
package ArrayPrograms;

import java.util.Scanner;

public class Array3 
{
	public static void main(String[] args) 
	{ 
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Size");
		int size=sc.nextInt();
		System.out.println("Enter the elements");
		int a[]=new int[size];
		int count=0;
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			count++;
		}
		System.out.println("Number of elements : "+count);
		
	}

}

package ArrayPrograms;

import java.util.Scanner;

public class RemoveDuplicates
{
	public static int[] duplicateValues(int a[])
	{
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]!=0&&a[i]==a[j]&&a[j]!=0)
				{
					a[j]=0;
				}
			}
		}
		int count=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==0)
				count++;
		}
		int b[]=new int[a.length-count];
		int k=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]!=0)
				b[k++]=a[i];
		}
		for(int i=0;i<a.length;i++)
		{
			System.out.println(b[i]);
		}
		return b;
	}
	
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int a[]=new int[sc.nextInt()];
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		duplicateValues(a);		
	}
}

package Programs;

import java.util.Scanner;

public class NeonNumber 
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		int sqr=num*num;
		int sum=0;
		
		while(sqr>0)
		{
			int last=sqr%10;
			sqr/=10;
			sum=sum+last;
		}
		if(sum==num)
			System.out.println("Neon Number");
		else
			System.out.println("Not a Neon Number");
	}

}

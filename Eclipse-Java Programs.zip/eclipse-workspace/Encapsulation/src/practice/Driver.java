package practice;

public class Driver 
{
void driver(Car c)
{
	c.start();
	c.move();
	c.stop();
}
}

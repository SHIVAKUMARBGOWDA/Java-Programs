package practice;

public class OverspeedException extends Exception
{
private String message="Overspeed";

	public String getMessage()
	{
		return message;
	}
}

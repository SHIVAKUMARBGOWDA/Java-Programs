package practice;

import java.util.InputMismatchException;
import java.util.Scanner;

public class VotingDriver 
{
	public static void main(String[] args) throws NotEligibleforVote
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the age");
		try 
		{
			int age=sc.nextInt();
			Voting v=new Voting(age);
			try
			{
				v.checkEligibility();
			}
			catch(NotEligibleforVote e)
			{
			System.out.println("Not Eligible for Vote");	
			}
		}
		catch(InputMismatchException e)
			{
			System.out.println("Invalid age please give the correct age");
			}
		}
	}



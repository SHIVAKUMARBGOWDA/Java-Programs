package practice;

public interface Car
{
	void start();
	void move();
	void stop();
}
class BMW implements Car
{

	@Override
	public void start() 
	{
		System.out.println("BMW car started");
		
	}

	@Override
	public void move()
	{
		System.out.println("BMW car is moving");
		
	}

	@Override
	public void stop() 
	{
		System.out.println("BMW car stopped");
	
	}
}
class Benz implements Car
{

	@Override
	public void start() 
	{
		System.out.println("Benz car started");
		
	}

	@Override
	public void move() 
	{
		System.out.println("Benz car is moving");
		
	}

	@Override
	public void stop() 
	{
		System.out.println("Benz car stopped");
		
	}
	
}
class Maruti implements Car
{

	@Override
	public void start() {
		System.out.println("Maruti car started");
		
	}

	@Override
	public void move() 
	{
		System.out.println("Maruti car is moving");
		
	}

	@Override
	public void stop() 
	{
		System.out.println("Maruti car stopped");
		
	}
	
}


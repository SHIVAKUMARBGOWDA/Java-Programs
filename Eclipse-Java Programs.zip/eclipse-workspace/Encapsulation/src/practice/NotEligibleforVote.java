package practice;

public class NotEligibleforVote extends Exception 
{

}

package practice;
abstract class SuperDemo
{
public static void display()
{
	System.out.println("display is implemented in abstract class");
}
public abstract void wish();
}

public class DemoMain extends SuperDemo
{
	

	public static void main(String[] args)
	{
		
	
			DemoMain dm=new DemoMain();
			dm.wish();
			dm.display();
		
	}

	public void wish()
	{

		System.out.println("wish is implemented in concrete class");
		
	}
		
	}




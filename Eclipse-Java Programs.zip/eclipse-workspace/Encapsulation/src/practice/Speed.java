package practice;

public class Speed
{
	int speed;
	Speed()
	{
		
	}
	Speed(int speed)
	{
		this.speed=speed;
	}
	public void checkSpeed()throws OverspeedException
	{
		if(speed<80)
		{
			System.out.println("Economic Speed");
		}
		else
			throw new OverspeedException();
	}
}

package practice;

public class Voting 
{
	int age;
	Voting()
	{
		
	}
	Voting(int age)
	{
		this.age=age;
	}
	public void checkEligibility() throws NotEligibleforVote
	{
		if(age>18)
			System.out.println("Eligible for vote");
		else
			throw new NotEligibleforVote();
			
	}
}

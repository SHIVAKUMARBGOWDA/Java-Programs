package practice;
import java.util.Scanner;
public class FactoryClass 
{
	static Car getCar()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Car Name");
		String carName=sc.next();
		if (carName.equals("BMW"))
		{
			return new BMW();
		}
		else if (carName.equals("Benz"))
		{
			return new Benz();
		}
		else if(carName.equals("Maruti"))
		{
			return new Maruti();
		}
		return null;
	}

}

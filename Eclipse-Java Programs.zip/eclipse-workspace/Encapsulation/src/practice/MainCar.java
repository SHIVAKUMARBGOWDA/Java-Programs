package practice;

public class MainCar
{

	public static void main(String[] args) 
	{
		Driver d=new Driver();
		Car c=FactoryClass.getCar();
		d.driver(c);

	}

}

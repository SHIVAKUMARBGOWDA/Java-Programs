package practice;

import java.util.InputMismatchException;
import java.util.Scanner;

public class SpeedDriver 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Speed");
		try
		{
			int speed=sc.nextInt();
			Speed s=new Speed(speed);
			try
			{
				s.checkSpeed();
			}
			catch(OverspeedException e)
			{
				System.out.println(e.getMessage());
			}
		}
		catch(InputMismatchException e)
		{
			System.out.println();
		}
	}
}


public class PhonepayMain
{

	public static void main(String[] args) 
	{
		Phonepay p=new Phonepay();
		p.setLockscreen(123456789);
		p.setUsername("Shivakumar");
		System.out.println(p.getLockscreen());
		System.out.println(p.getUsername());
	

	}

}

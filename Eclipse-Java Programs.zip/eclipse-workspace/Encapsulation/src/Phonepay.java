
public class Phonepay 
{
	private int lockscreen;
	private String username;
	public int getLockscreen() {
		return lockscreen;
	}
	public void setLockscreen(int lockscreen) {
		this.lockscreen = lockscreen;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}

}

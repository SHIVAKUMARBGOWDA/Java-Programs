
public class BankMain {

	public static void main(String[] args) 
	{
		EncapBank eb=new EncapBank();
		eb.setUsername("Dinga");
		eb.setPassword("Dinga@123");
		System.out.println(eb.getUsername());
		System.out.println(eb.getPassword());
		eb.getBalance();

	}

}

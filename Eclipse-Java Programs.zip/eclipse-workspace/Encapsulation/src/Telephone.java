
class Telephone
{
	public void calling()
	{
		System.out.println("calling from landline phone");
	}
}
class Nokia extends Telephone
{
	public void messaging()
	{
		System.out.println("messaging from Nokia phone");
	}
}
class Iphone extends Nokia
{
	public void reels()
	{
		System.out.println("Reels from Iphone");
	}
}

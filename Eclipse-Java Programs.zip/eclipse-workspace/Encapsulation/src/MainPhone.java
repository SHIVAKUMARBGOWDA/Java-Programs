
 class MainPhone
 {

	public static void main(String[] args) 
	{
		Telephone t=new Iphone();
				  
				  t.calling();
		Iphone i=(Iphone)t;
		i.calling();
		i.messaging();
		i.reels();
	}

}

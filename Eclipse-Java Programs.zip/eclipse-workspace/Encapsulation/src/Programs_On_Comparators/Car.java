package Programs_On_Comparators;

import java.util.Comparator;

public  class Car 
{
	private String company;
	private String color;
	private double price;
	private int model;
	public Car(String company, String color, double price, int model) 
	{
		this.company = company;
		this.color = color;
		this.price = price;
		this.model = model;
	}
	public String getCompany() 
	{
		return company;
	}
	
	public String getColor()
	{
		return color;
	}
	
	public double getPrice() 
	{
		return price;
	}
	
	public int getModel() 
	{
		return model;
	}
	
	@Override
	public String toString() 
	{
		return "[" + company + "," + color + "," + price + "," + model + "]";
	}
	@Override
	public boolean equals(Object o)
	{
		Car c=(Car)o;
		return this.company.equals(c.company) && this.color.equals(c.color) && this.price==c.price 
				&& this.model==c.model;
	}
	@Override
	public int hashCode()
	{
		return (int) (company.hashCode()+color.hashCode()+price+model);
	}	
}

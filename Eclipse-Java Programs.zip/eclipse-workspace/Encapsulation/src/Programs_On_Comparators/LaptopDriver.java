package Programs_On_Comparators;

import java.util.Arrays;
public class LaptopDriver 
{
	public static void main(String[] args) 
	{	
	Laptop [] a= {new Laptop(12,4,"Dell",40000),new Laptop(32,6,"Lenovo",60000),
					new Laptop(50,8,"MI",50000),new Laptop(52,4,"Acer",60000)};
	System.out.println("Before Sorting..");
	for (int i=0;i<a.length;i++)
	{
		System.out.println(a[i]);
	}
	System.out.println("====After Sorting by id====");
	Arrays.sort(a);
	for(int i=0;i<a.length;i++)	{
		System.out.println(a[i]);
	}
	}
}

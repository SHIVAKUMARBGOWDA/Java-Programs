package Programs_On_Comparators;

import java.util.Comparator;

public class CompareByCompany implements Comparator
{

	@Override
	public int compare(Object o1, Object o2)
	{
		Car c1=(Car)o1;
		Car c2=(Car)o2;
		return c1.getCompany().compareTo(c2.getCompany());
	}

}

package Programs_On_Comparators;

public class Book implements Comparable
{
	private int id;
	private String author;
	private double price;
	
	public Book(int id, String author,double price)
	{
		this.id=id;
		this.author=author;
		this.price=price;
	}
	public int getId()
	{
		return id;
	}
	public String getAuthor()
	{
		return author;
	}
	public double getPrice() 
	{
		return price;
	}
	@Override
	public String toString()
	{
		return "["+id+","+author+","+price+"]";
	}
	@Override
	public boolean equals(Object o)
	{
		Book b=(Book)o;
		return this.id==b.id && this.author.equals(b.author) && this.price==b.price;
	}
	@Override
	public int hashCode()
	{
		return id+author.hashCode()+(int)price;
	}
	@Override
	public int compareTo(Object o)
	{
		Book b=(Book)o;
		int s=this.author.compareTo(b.author);
		return s;
	}
}

package Programs_On_Comparators;

public class Laptop implements Comparable
{
	int id;
	int ram;
	String brand;
	double price;
	Laptop()
	{
		
	}
	
	public Laptop(int id,int ram,String brand,double price)
	{
		this.id=id;
		this.ram=ram;
		this.brand=brand;
		this.price=price;
	}
	@Override
	public String toString()
	{
		return "["+id+", "+ram+","+brand+","+price+"]";
	}
	@Override
	public boolean equals(Object o)
	{
		Laptop l=(Laptop)o;
		return this.id==l.id &&this.ram==l.ram && this.brand.equals(l.brand) && this.price==l.price;
	}
	@Override
	public int hashCode()
	{
		return id+ram+brand.hashCode()+(int)price;
	}
	public int compareTo(Object o) //comparing by id
	{
		Laptop l=(Laptop)o;
		if(this.id>l.id)
			return 1;
		else if(this.id==l.id)
			return 0;
		else
			return -1;
//		int s=this.brand.compareTo(l.brand); //comparing by String
//		
//		return s;
			
	}
	
	}
	


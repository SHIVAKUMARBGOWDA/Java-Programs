package Programs_On_Comparators;

import java.util.Arrays;

public class CarDriver
{
	public static void main(String[] args) 
	{	Car[] c= { new Car("BMW","Blue",5500000,2020),new Car("Jaguar","Orange",4600000,2006),
			   new Car("Porsche","Black",8300000,2021),new Car("Audi","White",6000000,2020),
			   new Car("Toyato","Red",3200000,2017)};
	System.out.println("=====Before Sorting=====");
	for(int i=0;i<c.length;i++)
	{
		System.out.println(c[i]);
	}
	System.out.println("");
	Arrays.sort(c,new CompareByCompany());
	System.out.println("=====Sorting according to Company=====");
	for(int i=0;i<c.length;i++)
	{
		System.out.println(c[i]);
	}
	System.out.println("");
	Arrays.sort(c,new CompareByColor());
	System.out.println("=====Sorting according to Color=====");
	for(int i=0;i<c.length;i++)
	{
		System.out.println(c[i]);
	}
	System.out.println("");
	Arrays.sort(c,new CompareByPrices());
	System.out.println("=====Sorting according to Price=====");
	for(int i=0;i<c.length;i++)
	{
		System.out.println(c[i]);
	}
	System.out.println("");
	Arrays.sort(c,new CompareByModel());
	System.out.println("=====Sorting according to model=====");
	for(int i=0;i<c.length;i++)
	{
		System.out.println(c[i]);
	}
	}

}

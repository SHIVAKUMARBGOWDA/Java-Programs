package Programs_On_Comparators;

import java.util.Arrays;

public class BookDriver 
{
	public static void main(String[] args) 
	{

		Book[] b= new Book[5];
		b[0]=new Book(11,"Arun Tiware",450);
		b[1]=new Book(13,"Joseph Murphy",200);
		b[2]=new Book(15,"Arundhati Roy",499);
		b[3]=new Book(14,"Bishwanath Singh",200);
		b[4]=new Book(12,"Chetan Bhagat",250);
		System.out.println("Before Sorting");
		for (int i=0;i<b.length;i++)
		{
			
			System.out.println(b[i]);
		}
		System.out.println("===============================");
//		Arrays.sort(b);
		Arrays.sort(b,new CompareById());
		
		System.out.println("====After Sorting By Id====");
		for (int i=0;i<b.length;i++)
		{
			System.out.println(b[i]);
		}
		Arrays.sort(b,new CompareByAuthor());
		System.out.println("====After Sorting By Author====");
		for (int i=0;i<b.length;i++)
		{
			System.out.println(b[i]);
		}
		Arrays.sort(b,new CompareByPrice());
		System.out.println("====After Sorting By Price====");
		for (int i=0;i<b.length;i++)
		{
			System.out.println(b[i]);
		}
	}
}

package DataStructures;

import java.util.Scanner;

public class StackDriver 
{
	public static void main(String[] args) 
	{
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Size of the Stack");
		int size=sc.nextInt();
		Stack s=new Stack(size);
		boolean flag=false;
		while(!flag)
		{
			System.out.println("******************");
			System.out.println("1.PUSH");
			System.out.println("2.POP");
			System.out.println("3.isFull");
			System.out.println("4.isEmpty");
			System.out.println("5.Show stack elements");
			System.out.println("6.Exit");
			System.out.println("******************");
			System.out.println("Choose from above");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:
			{
				System.out.println("Enter the element pushed");
				int element=sc.nextInt();
				s.push(element);
			}break;
			case 2: 
			{
				s.pop();
			}break;
			case 3:
			{
				System.out.println(s.isFull());
			}break;
			case 4:
			{
				System.out.println(s.isEmpty());
			}break;
			case 5:
			{
				System.out.println(s);
			}break;
			case 6:
			{
				flag=true;
			}break;
			default:
			{
				System.out.println("Invalid choice");
			}
			}
		}
			System.out.println("Thank You!!!!!........");
	}

}

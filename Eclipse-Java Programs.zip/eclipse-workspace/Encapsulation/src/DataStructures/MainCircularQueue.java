package DataStructures;

import java.util.Scanner;

public class MainCircularQueue 
{
	public static void main(String[] args)
	{

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Size of the Queue");
		int size=sc.nextInt();
		CircularQueue c=new CircularQueue(size);
		boolean flag=false;
		while(!flag)
		{
			System.out.println("******************");
			System.out.println("1.Enqueue");
			System.out.println("2.Dequeue");
			System.out.println("3.isFull");
			System.out.println("4.isEmpty");
			System.out.println("5.Show Queue elements");
			System.out.println("6.Exit");
			System.out.println("******************");
			System.out.println("Choose from above");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:
			{
				System.out.println("Enter the element Enqueed");
				int element=sc.nextInt();
				c.enqueue(element);
			}break;
			case 2: 
			{
				c.dequeue();
			}break;
			case 3:
			{
				System.out.println(c.isFull());
			}break;
			case 4:
			{
				System.out.println(c.isEmpty());
			}break;
			case 5:
			{
				System.out.println(c);
			}break;
			case 6:
			{
				flag=true;
			}break;
			default:
			{
				System.out.println("Invalid choice");
			}
			}
		}
			System.out.println("Thank You!!!!!........");
	}
	}



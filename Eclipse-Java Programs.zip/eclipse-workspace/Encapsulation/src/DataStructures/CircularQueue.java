package DataStructures;

public class CircularQueue 
{
	int front;
	int rear;
	int arr[];
	int capacity;
	CircularQueue(int capacity)
	{
		front=rear=-1;
		arr=new int[capacity];
		this.capacity=capacity;
	}
	public boolean isEmpty()
	{
		return front==-1;
	}
	public boolean isFull()
	{
		return (rear+1)%capacity==front;
	}
	public void enqueue(int data)
	{
		if(isFull())
		{
			System.out.println("Queue Overflow");
		}
		else
		{
			if(front==-1)
			{
				rear=front=0;
				arr[rear]=data;
				System.out.println(data+" added to the queue successfully");
			}
			else
			{
				rear=(rear+1)%capacity;
				arr[rear]=data;
				System.out.println(data+" added to the queue successfully");
			}
		}
	}
	public void dequeue()
	{
		if(isEmpty())
		{
			System.out.println("Queue Underflow");
		}
		else
		{
			int data=arr[front];
			if(rear==front)
			{
				front=rear=-1;
			}
			else
			{
				front=(front+1)%capacity;
				System.out.println(data+" removed to the queue successfully");

			}
		}
	}
	public String toString()
	{
		String s1="[";
		for(int i=front;(i!=rear ||rear==i) && rear!=-1;i=(i+1)%capacity)
		{
			if(i!=rear)
			{
				s1+=arr[i]+",";
			}
			else
			{
				s1+=arr[i];
				break;
			}
		}
		s1+="]";
		return s1;
		
	}
}

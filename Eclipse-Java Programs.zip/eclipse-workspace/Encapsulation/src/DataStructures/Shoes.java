package DataStructures;

public class Shoes implements Comparable
{
	private String brand;
	private String color;
	private double price;
	private int size;
	public Shoes(String brand, String color, double price, int size)
	{
		super();
		this.brand = brand;
		this.color = color;
		this.price = price;
		this.size = size;
	}
	public String getBrand() 
	{
		return brand;
	}
	public String getColor() 
	{
		return color;
	}
	public double getPrice() 
	{
		return price;
	}
	public int getSize() 
	{
		return size;
	}
	@Override
	public String toString() 
	{
	 return "Shoes [ brand=" + brand + ", color=" + color + ", price=" + price + ", size=" + size + "]";
	}
	public int compareTo(Object o)
	{
		Shoes s=(Shoes)o;
		if(this.price>s.price)
			return 1;
		else if(this.price==s.price)
			return 0;
		else
			return -1;
	}	
}

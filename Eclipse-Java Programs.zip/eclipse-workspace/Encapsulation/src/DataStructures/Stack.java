package DataStructures;

public class Stack 
{
	int top;
	int arr[];
	int capacity;
Stack(int capacity)
{
	top=-1;
	arr=new int[capacity];
	this.capacity=capacity;
}
public boolean isEmpty()
{
	return (top==-1);
}
public boolean isFull()
{
	return (top==arr.length-1);
}
public void push(int data)
{
	if(isFull())
	{
		System.out.println("Stack Overflow");
	}
	else
	{
		arr[++top]=data;
		System.out.println(data+" pushed on to the stack successfully");
	}
}
public void pop()
{
	if(isEmpty())
	{
		System.out.println("Stack Underflow");
	}
	else
	{
		int data=arr[top--];
		System.out.println(data+" has been popped from the stack");	
	}
}
public String toString()
{
	String s1="[";
	for (int i=0;i<=top;i++)
	{
		if(i!=top)
			s1+=arr[i]+", ";
		else
			s1+=arr[i];
	}
	s1+="]";
	return s1;
}
}


package DataStructures;

import java.util.Iterator;
import java.util.PriorityQueue;

public class PriorityQueue1
{
	public static void main(String[] args) 
	{
		PriorityQueue pq=new PriorityQueue();
		pq.add(new Shoes("WildCraft","Black",2500,10));
		pq.add(new Shoes("Puma","White",1799,7));
		pq.add(new Shoes("Jimmy Choo","Brown",10000,9));
		pq.add(new Shoes("Adidas","Blue",1500,6));
		Iterator i=pq.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		pq.remove();
		System.out.println("=================");
		Iterator i1=pq.iterator();
		while(i1.hasNext())
		{
			System.out.println(i1.next());
		}
		System.out.println("=================");
		pq.remove();
		Iterator i2=pq.iterator();
		while(i2.hasNext())
		{
			System.out.println(i2.next());
		}
	}

}

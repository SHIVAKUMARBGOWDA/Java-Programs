package DataStructures;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class Collection 
{
	public static void main(String[] args)
	{
		ArrayList al=new ArrayList(5);
		//To add an elements
		al.add("sheela");
		al.add(10);
		al.add(true);
		al.add(10.68);
		al.add('S');
		System.out.println(al);
		
		ArrayList al1=new ArrayList();
		al1.add("maala");
		al1.add(60);
		al1.add('B');
		al1.add(false);
		al1.add(null);
		System.out.println(al1);
		System.out.println("===========================");
		al.addAll(al1);
		System.out.println(al);
		System.out.println("==========================");
		al.removeAll(al1);
		System.out.println(al);
		//To Iterate
		for (int i=0;i<al.size();i++)
		{
			System.out.println(al.get(i));
		}
		System.out.println("====From Iterator====");
		Iterator i=al.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		System.out.println("=======================");
		System.out.println("====List Iterator===========");
		System.out.println("====Forward==========");
		ListIterator li=al.listIterator();
		while(li.hasNext())
		{
			System.out.println(li.next());
		}
		System.out.println("========Backward==========");
		while(li.hasPrevious())
		{
			System.out.println(li.previous());
		}
	}

}

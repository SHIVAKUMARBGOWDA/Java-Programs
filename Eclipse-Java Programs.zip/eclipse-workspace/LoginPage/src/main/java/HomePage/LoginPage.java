package HomePage;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class LoginPage extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String name=req.getParameter("myname");
		if(name.equals("Rajesh"))
		{
			RequestDispatcher rd=req.getRequestDispatcher("Welcome");
			
			rd.forward(req, resp);
		}
		else
		{
			resp.setContentType("text/html");
			RequestDispatcher rd=req.getRequestDispatcher("login.html");
			
			PrintWriter pw=resp.getWriter();
			pw.print("Name is not found");
			rd.include(req, resp);
		}
	}

}

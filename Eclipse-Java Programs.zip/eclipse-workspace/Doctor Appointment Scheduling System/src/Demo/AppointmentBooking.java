package Demo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class AppointmentBooking 
{
	ArrayList<String> dName=new ArrayList<String>();
	ArrayList<String> dQualification=new ArrayList<String>();
	ArrayList<String> dGender=new ArrayList<String>();
	ArrayList<String> dPassword=new ArrayList<String>();
	ArrayList<Integer> dAge=new ArrayList<Integer>();
	ArrayList<Long> dMobileNumber=new ArrayList<Long>();
	ArrayList<String> dCity=new ArrayList<String>();

	ArrayList<Integer> pAge=new ArrayList<Integer>();
	ArrayList<String> pName=new ArrayList<String>();
	ArrayList<String> pGender=new ArrayList<String>();
	ArrayList<String> pPassword=new ArrayList<String>();
	ArrayList<String> pConfirmPassword=new ArrayList<String>();
	ArrayList<Long> pMobileNumber=new ArrayList<Long>();

	ArrayList<Integer> patientAgeBooking=new ArrayList<Integer>();
	ArrayList<String> patientNameBooking=new ArrayList<String>();
	ArrayList<String> patientGenderBooking=new ArrayList<String>();
	ArrayList<Byte> doctorID=new ArrayList<Byte>();

	public void dataAdd()		//method for creating Default docotr list present in the database.
	{
		dName.add("Nagarjun");
		dName.add("Shivakumar");
		dName.add("Ramya");
		dName.add("Akshay");
		dName.add("Asha");
		dName.add("Rajesh");
		dName.add("Shekhar");

		dQualification.add("MBBS");
		dQualification.add("Er, MBBS");
		dQualification.add("MBBS, MD");
		dQualification.add("MBBS,MD");
		dQualification.add("BAMS");
		dQualification.add("MBBS, MD, Surgeon");
		dQualification.add("BAMS");

		dGender.add("M");
		dGender.add("M");
		dGender.add("F");
		dGender.add("M");
		dGender.add("F");
		dGender.add("M");
		dGender.add("M");

		dPassword.add("Nagarjun");
		dPassword.add("Shiva123");
		dPassword.add("Ramya123");
		dPassword.add("Akshay321");
		dPassword.add("Asha987");
		dPassword.add("Raju143");
		dPassword.add("Shekhar");

		dAge.add(25);
		dAge.add(23);
		dAge.add(23);
		dAge.add(29);
		dAge.add(28);
		dAge.add(23);
		dAge.add(30);

		dMobileNumber.add(9422887565l);
		dMobileNumber.add(9110664616l);
		dMobileNumber.add(9008046135l);
		dMobileNumber.add(9876543210l);
		dMobileNumber.add(9987654321l);
		dMobileNumber.add(9632587410l);
		dMobileNumber.add(9874563210l);

		dCity.add("Banglore");
		dCity.add("Banglore");
		dCity.add("Mysore");
		dCity.add("Tirupati");
		dCity.add("Chennai");
		dCity.add("Delhi");
		dCity.add("Chennai");
	}

	public void admin() throws InterruptedException, IOException 
	{
		Scanner sc=new Scanner(System.in);
		int choice;
		boolean flag=true;

		while(flag)
		{
			new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
			System.out.println(" ");
			System.out.println("Welcome Admin");
			System.out.print("1. Doctor list  2. Registered Patients 3.Pateints with Appointment   Enter Your Choice: ");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				for(int i=0; i<=dName.size()-1; i++)
				{
					System.out.println("Name:  "+dName.get(i));
				
				}
				int menuChoice;
				System.out.println("1. Main menu  2. Previous menu");
				menuChoice=sc.nextInt();
				if(menuChoice==1)
				{
					flag=false;
					
				}
				else
				{
					break;
				}

				break;

			case 2:
					if(pName.isEmpty())
					{
						System.out.println("No Patients Registered yet....");
						Thread.sleep(3000);
						break;
					}
					else 
					{
						for(int i=0; i<=pName.size()-1; i++)
						{
							System.out.println(i+1+"."+pName.get(i));
						}

						System.out.println("1. Main menu  2. Previous menu");
						menuChoice=sc.nextInt();
						if(menuChoice==1)
						{
							flag=false;						
						}
						else
						{
							break;
						}
					}					
					break;
			case 3:
				if(patientNameBooking.isEmpty())
				{
					System.out.println("Still No Appointments yet.");
					Thread.sleep(3000);
					break;
				}				
				else
				{
					for(int i=0; i<=patientNameBooking.size()-1; i++)
					{
						System.out.println(i+". "+patientNameBooking.get(i));
					}

					Thread.sleep(5000);
					flag=false;
				}
				break;
			default:
					System.out.println("Invalid choice");
					Thread.sleep(1000);
					flag=true;
			}
		}	
	}

	public void patient() throws Exception 
	{
		Scanner sc=new Scanner(System.in);
		boolean flag=true;
		while(flag)
		{
			new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
			System.out.println(" ");
			System.out.println("Welcome to Patient Page");
			System.out.println();
			System.out.println("1.Login  2.Registration ");
			int input=sc.nextInt();
			switch(input)
			{
				case 1:
					if(pMobileNumber.isEmpty())
					{
						System.out.println("First register yourself then login..!");
						Thread.sleep(500);
						break;
					}
					else
					{
						patientLogin();
						flag=false;						
					}					
					break;
				case 2:
					patientRegistration();
					flag=false;
					break;
				default:
					System.out.println("You are entered invalid choice. enter your choice again....!!!");
					flag= true;
					Thread.sleep(1000);
					break;
			}
		}
	}

	public void doctor() throws Exception
	{	
		Scanner sc=new Scanner(System.in);
		int choice=0;		
		boolean flag=true;
		while(flag)
		{
			new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
			System.out.println(" ");
			System.out.println("Welcome to Doctor Page!");
			System.out.println(" ");
			System.out.println("1. Login   2.Registration");
			choice=sc.nextInt();

			switch(choice)
			{
			case 1:
				if(dMobileNumber.isEmpty())
				{
					System.out.println("Register first...!");
					flag=false;
					Thread.sleep(500);
					break;
				}
				else
				{
					doctorLogin();
					flag=false;
				}
				break;
			case 2:
				doctorRegistration();
				flag= false;
				break;

			default:
				System.out.println("Enter valid choice..");
				flag=true;
			}
		}	
	}
	
	public void patientLogin()throws Exception
	{

		Scanner sc=new Scanner(System.in);
		boolean flag=true;
		long mobileNumber;
		byte choice;
		new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
		System.out.println(" ");
		System.out.println("LOGIN Page");
		System.out.println("Enter your Username/MobileNumber");
		mobileNumber=sc.nextLong();
		System.out.println("Enter your Password");
		String psw=sc.next();
			
 		boolean b=false;
 		int j;
		for(j=0; j<=pMobileNumber.size()-1;j++)
		{			
			if((pMobileNumber.get(j)).equals(mobileNumber)&&(pPassword.get(j)).equals(psw))
			{
				b=true;
				break;
			}			
		}
		if(b==true)
		{		
			Thread.sleep(1000);
			new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
				System.out.println();
				System.out.println(" Book Appointment ");
				System.out.println();
				System.out.println(" Welcome "+pName.get(j)+", to book appointment, choose your doctor..");
			
			for(int i=0; i<=dName.size()-1; i++)
			{
				System.out.println((i+1)+"."+dName.get(i));
			}
			choice=sc.nextByte();
			doctorID.add(choice);
				
			while(b)
			{
				Thread.sleep(1000);
				new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
				System.out.println("");
				System.out.println("Book Appointment");
				System.out.println();
				for(int i=0; i<=dName.size()-1;i++)
				{
					if(choice<=dName.size() && choice>0)
					{
						System.out.println("Doctor details:- Name: "+dName.get(choice-1)+" Age: "+dAge.get(choice-1)+" Mobile:"+dMobileNumber.get(choice-1)+" City: "+dCity.get(choice-1));
						System.out.println("Patient Details: ");
						System.out.println(" Enter you name: ");
						String s=sc.next();
						patientNameBooking.add(s);
						System.out.println(" Enter your age: ");
						int age=sc.nextInt();
						patientAgeBooking.add(age);
						System.out.println(" Enter your gender: ");
						String gen=sc.next();
						patientGenderBooking.add(gen);

						System.out.println("Booking Successfull..");

						Thread.sleep(1000);
						b=false;
						break;
					}
					else 
					{
						System.out.println(" Enter correct input..");
						b=true;
						Thread.sleep(1000);
					}		
				}
			}	
		}
		else 
		{
			System.out.println("Login Unsuccessfull..");
			Thread.sleep(900);
			b=false;
		}
	}

	public void patientRegistration() throws Exception
	{
		Scanner sc=new Scanner(System.in);
		int i=0;
		long mobileNumber;
		new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
		System.out.println();
		System.out.println("---------------Welcome to Patient Registration Page!-----------------------");
		System.out.println();
		System.out.println("Please enter your name");
		pName.add(sc.nextLine());
		System.out.println("Enter your age: ");
		pAge.add(sc.nextInt());
		System.out.println("Please enter your Mobile number");
		mobileNumber=sc.nextLong();
		long ph_num;
		
		boolean flag=true, flag1=true;
		
		if(pMobileNumber.isEmpty())
		{
			pMobileNumber.add((mobileNumber));
			System.out.println("Enter password");
			pPassword.add(sc.next());
			System.out.println("Registration is Successfull.");
			
			Thread.sleep(900);
			flag1=false;
						
		}
		else 
		{
			for(i=0;i<=pMobileNumber.size()-1;i++)
			{
				ph_num=pMobileNumber.get(i);
				
				if(ph_num==mobileNumber)
				{					
					flag1=false;
					break;
				}				
			}
			if(flag1==true)
			{
			pMobileNumber.add(mobileNumber);
			System.out.println("Enter password");
			pPassword.add(sc.next());
			System.out.println("Registration is Successfull.");
			Thread.sleep(900);
			}
			else 
			{
				System.out.println("Same mobile numebr is not allowed");
				Thread.sleep(500);
			}
		}
	}

	public void doctorRegistration() throws Exception
	{
		Scanner sc=new Scanner(System.in);
		int i=0;
		long mobileNumber;
		boolean b=true;
					
			new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();

			System.out.println("");
			System.out.println("--------------Doctor registration Page---------------- ");
			System.out.println();
			System.out.println();
			
			System.out.println("Please enter your name");
			dName.add(sc.nextLine());

			System.out.println("Please enter your Mobile number");
			mobileNumber=(sc.nextLong());
			
			long ph;

				if(dMobileNumber.isEmpty())
					{
						dMobileNumber.add((mobileNumber));
						System.out.println("Enter password");
							dPassword.add(sc.next());
							System.out.println("Registration is Successfull.");
							Thread.sleep(1000);
							b=false;					
					}
				else 
				{
					for(i=0;i<=dMobileNumber.size()-1;i++)
					{
						ph=dMobileNumber.get(i);
						
						if(ph==mobileNumber)
						{							
							b=false;
							break;
						}							
					}
					if(b==true)
					{
						dMobileNumber.add(mobileNumber);
						System.out.println("Enter age:");
						dAge.add(sc.nextInt());
						System.out.println("Enter City: ");
						dCity.add(sc.next());
						System.out.println("Enter password");
						dPassword.add(sc.next());
						System.out.println("Registration is Successfull.");
						System.out.println("Details: Name: "+dName+" number:"+dMobileNumber);
						Thread.sleep(900);
					}
					else
					{
						System.out.println("Same mobile numebr is not allowed");
						int index=dName.size()-1;
						dName.remove(index);
						Thread.sleep(1000);
					}
				}
	}

	public void doctorLogin() throws Exception
	{
		Scanner sc=new Scanner(System.in);
		Long phno;
		Thread.sleep(500);
		new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
		System.out.println("---------------------------------");
		System.out.println("----------Doctor login page-----------");
		System.out.println("---------------------------------");
		System.out.println("Enter your Username/Mobilenumber");
		phno=sc.nextLong();
		System.out.println("Enter your Password");
		String password=sc.next();
		int i=0;
		int choice;
 		
 		boolean flag=false;
 		boolean flag1=true;

		for(i=0; i<=dMobileNumber.size()-1;i++)
		{
			
			if((dMobileNumber.get(i)).equals(phno)&&(dPassword.get(i)).equals(password))
			{
				flag=true;
				break;
			}
		}
		
			if(flag==true)
			{
				while(flag1)
				{
					new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
					System.out.println("----------------------------------------");
					System.out.println(" Welcome Doctor "+dName.get(i)+" |");
					System.out.println("----------------------------------------");
					System.out.println("Press 1 to see your Appointments");
					choice=sc.nextByte();
					int j=0;
					switch(choice)
					{
					case 1:
						if((doctorID.isEmpty()!=true))
						{
							while(j<=doctorID.size()-1)
							{
								if( (i+1)== doctorID.get(j) )
								{
									System.out.println("patient name: "+patientNameBooking.get(j) );
									j++;							
								}
							}
							Thread.sleep(1000);							
						}
						else 
							{
								System.out.println("No Appointments...!");
								Thread.sleep(1000);
								flag1=true;
							}
						break;
					}
					System.out.println("Press  2 to back to the main page");
					System.out.println("1. Main menu  2. Previous menu");
					int menuChoice=sc.nextInt();
					if(menuChoice==1)
					{
						flag=false;						
					}
					else
					{
						break;
					}
					System.out.println("Still no patients appointed..");
				}
			}
							
				else 
				{
					System.out.println("Login Unsuccessfull..");
					Thread.sleep(1900);	
				}
			}	

	public static void main(String[] args) throws Exception   
	{
		AppointmentBooking ap=new AppointmentBooking();
		Scanner sc=new Scanner(System.in);
		ap.dataAdd();
		boolean flag=true;
		while(flag=true)
		{			
			new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();		
			System.out.println("---------------------------------------------------------------------");
			System.out.println("........ Welcome to Doctor AppointmentBooking......");
			System.out.println("----------------------------------------------------------------------");
			System.out.println("1. Doctor   2. Patient   3. Admin   4. Exit");
			int choice=sc.nextInt();
			switch(choice)
			{
				case 1:
					ap.doctor();
					flag=true;
					break;
					case 2:
					ap.patient();										
					flag=true;
					break;
					case 3:					
					ap.admin();
					flag= true;
					break;
					case 4:
					System.exit(0);
					break;
					default:
						System.out.println("Invalid Choice");
			}
		}
	}
}

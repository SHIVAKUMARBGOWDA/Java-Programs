package Demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class TableCreation 
{
	@Id
	private int id;
	//@Column(name = "NAME")
	private String name;
	//@Column(name = "AGE")
	private int age;
	//@Column(name = "EMAIL-ID")
	private String email;
	//@Column(name = "PHONE-NUMBER")
	private long ph_no;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getPh_no() {
		return ph_no;
	}
	public void setPh_no(long ph_no) {
		this.ph_no = ph_no;
	}
	
	
	

}

package Demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Insertion
{
	public static void main(String[] args)
	{
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("java");
		
		EntityManager manager=factory.createEntityManager();
		
		EntityTransaction transaction=manager.getTransaction();
		
		TableCreation t=new TableCreation();
		
		t.setId(4);
		t.setAge(23);
		t.setName("DHARANESH.G");
		t.setEmail("dharani@gmail.com");;
		t.setPh_no(8865456628l);
		
		transaction.begin();
		manager.persist(t);
		transaction.commit();
	
	}

}

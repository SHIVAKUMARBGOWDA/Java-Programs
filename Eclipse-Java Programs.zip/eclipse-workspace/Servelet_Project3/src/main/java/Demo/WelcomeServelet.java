package Demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/welcome")
public class WelcomeServelet extends HttpServlet
{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
{
	//Fetching data
	String name=req.getParameter("myname");
	
	if(name.equals("shiva"))
	{
		//creating request dispatcher object
		RequestDispatcher rd=req.getRequestDispatcher("home");
		
		//Forwarding request to another resourse
		rd.forward(req, resp);
	}
	else
	{
		RequestDispatcher rd=req.getRequestDispatcher("Welcome.html");
		
		//For generating response
		PrintWriter pw=resp.getWriter();
		
		resp.setContentType("text/html");
		
		pw.print("<h3 style=color:red> Name is not matching..... </h3>");
		rd.include(req, resp);
	}
}
}

package DAO;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import DTO.Employee;

public class EmployeDAO
{
	public EntityManager getEntityManager()
	{
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("shiva");
		EntityManager manager=factory.createEntityManager();
		return manager;
	}
	
	public void insertEmployee(Employee emp)
	{		
		EntityTransaction transaction=getEntityManager().getTransaction();
		transaction.begin();
		getEntityManager().persist(emp);
		transaction.commit();		
	}		
}

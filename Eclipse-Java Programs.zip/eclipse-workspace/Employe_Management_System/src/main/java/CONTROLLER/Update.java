package CONTROLLER;

import DAO.EmployeDAO;
import DTO.Employee;

public class Update 
{
	public static void main(String[] args) {
		
		EmployeDAO dao=new EmployeDAO();
		Employee emp=dao.getEntityManager().find(Employee.class, 1);
		if(emp!=null)
		{
			//Set the values
			emp.setName("Shivu");
			emp.setDesignation("Software Developer");
			
			//Merge or update the new object into database
			dao.insertEmployee(emp);
		}
		else
			System.out.println("Id is not found");
	}

}

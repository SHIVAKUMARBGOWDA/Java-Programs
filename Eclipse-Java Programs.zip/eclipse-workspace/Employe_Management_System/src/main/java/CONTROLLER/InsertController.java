package CONTROLLER;

import DAO.EmployeDAO;
import DTO.Employee;

public class InsertController 
{
	public static void main(String[] args) 
	{	
		EmployeDAO dao=new EmployeDAO();
		dao.getEntityManager();
		
		Employee emp=new Employee();
		
		emp.setId(1);
		emp.setName("ShivaKumar");
		emp.setDesignation("Software Engineer");
		emp.setSalary(250000);
		
		dao.insertEmployee(emp);
		
		System.out.println(emp.getId()+" "+emp.getName()+" "+emp.getDesignation()+" "+emp.getSalary());
	}
	

}

package Demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class InsertData 
{
	public static void main(String[] args) 
	{
		//Creating Entity Manager factory
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		//Creating Entity Manager
		EntityManager manager=factory.createEntityManager();
		//Create Entity Transaction
		EntityTransaction transaction=manager.getTransaction();
		
		//Creating Object
		ConvertTable ct=new ConvertTable();
		//Setting values
		ct.setId(2);
		ct.setName("Prabhu");
		ct.setPh(9900641244l);
		
		//Persisting inserting object to database
		transaction.begin();
		manager.persist(ct);
		transaction.commit();
	}

}

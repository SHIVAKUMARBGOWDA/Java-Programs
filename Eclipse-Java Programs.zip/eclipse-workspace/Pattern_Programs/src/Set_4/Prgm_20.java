package Set_4;

import java.util.Scanner;
//AAAA
//1111
//BBBB
//2222
public class Prgm_20 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int row=sc.nextInt();
		char c='A';
		int num=1;
		for(char i=1;i<=row;i++)
		{
			for(int j=1;j<=row;j++)
			{
				if(i%2==1)
					System.out.print(c);
				
				else
					System.out.print(num);
			}
			if(i%2==1)
				c++;
			else
				num++;
			System.out.println();
		}		
	}
}

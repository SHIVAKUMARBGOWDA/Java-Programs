package Set_4;

import java.util.Scanner;
//1
//ab
//123
//abcd
public class Prgm_27 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int row=sc.nextInt();
		
		for(int i=1;i<=row;i++)
		{
			char c='a';
			int num=1;
			for(int j=1;j<=i;j++)
			{
				if(i%2==1)
					System.out.print(num++);
				else
					System.out.print(c++);
			}
			System.out.println();
		}		
	}
}

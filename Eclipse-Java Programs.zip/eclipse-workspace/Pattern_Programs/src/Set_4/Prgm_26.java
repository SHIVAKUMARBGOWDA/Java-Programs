package Set_4;

import java.util.Scanner;
//a
//bc
//cde
//defg
public class Prgm_26 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int row=sc.nextInt();
		char c='a';
		for(int i=1;i<=row;i++)
		{
			char c1=c;
			for(int j=1;j<=i;j++)
			{
				System.out.print(c1++);
				
			}
			c++;
			System.out.println();
		}
	}
}

package Set_4;

import java.util.Scanner;
//*****
//*  *
//* *
//**
//*
public class Prgm_14 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int row=sc.nextInt();
		for(int i=1;i<=row;i++)
		{
			for(int j=row;j>=i;j--)
			{
				if(i==1||j==row|| i==j)
					System.out.print("*"); 
				else
					System.out.print(" ");
			}
			System.out.println();
		}	
		
	}
}

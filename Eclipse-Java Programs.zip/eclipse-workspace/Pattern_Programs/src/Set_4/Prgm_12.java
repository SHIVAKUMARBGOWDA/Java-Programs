package Set_4;

import java.util.Scanner;
//*****
//*  **
//* * *
//**  *
//*****
public class Prgm_12
{
	public static void main(String[] args)   //Secondary diagonal
	{
		Scanner sc=new Scanner(System.in);
		int row=sc.nextInt();
		for(int i=1;i<=row;i++)
		{
			for(int j=1;j<=row;j++)
			{
				if(i==1 ||i==row || j==1 || j==row ||i+j==row+1)
					System.out.print("*");
				else 
					System.out.print(" ");				
			}
			System.out.println();
		}
		
	}
}

package Set_4;

import java.util.Scanner;

public class V_Letter_Pattern
{
	public static void main(String[] args) {
        Scanner cs = new Scanner(System.in);
        System.out.println("Enter 1st number in the series: ");
		int n1=cs.nextInt();
		System.out.println("Enter 2nd number in the series: ");
		int n2=cs.nextInt();
        System.out.println("Enter the Number of lines: ");
        int row= cs.nextInt();
        int x = 1;
        int y = row*2-1;       
        for (int i=1;i<=row;i++) 
        {
            for (int j=1;j<=row*2;j++) 
            {
                if (j==x||j==y) 
                {
                	int n3=n1+n2;
                    System.out.print(n1);
                    n1=n2;
                    n2=n3;
                } 
                else
                    System.out.print(" ");
            }
            x++;
            y--;
            System.out.println();
        }
    }
    }


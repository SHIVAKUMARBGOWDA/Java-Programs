package Set_4;

import java.util.Scanner;
//#****
//*#***
//**#**   1
//***#*
//****#
//
//****#
//***#*
//**#**  2
//*#***
//#****
//
//****#
//***#*
//**#**  3
//*#***
//#****
public class Prgm_9 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int row=sc.nextInt();
		for(int i=1;i<=row;i++)    //Primary diagonal form
		{
			for(int j=1;j<=row;j++)
			{
				if(i==j)
					System.out.print("#");
				else 
					System.out.print("*");				
			}
			System.out.println();
		}
		System.out.println();
		
		
		for(int i=1;i<=row;i++)   //Secondary diagonal form
		{
			for(int j=row;j>0;j--)
			{
				if(i==j)
					System.out.print("#");
				else 
					System.out.print("*");				
			}
			System.out.println();
		}
		
		System.out.println();
		
		for(int i=1;i<=row;i++)    //R to L diagonal form
		{
			for(int j=1;j<=row;j++)
			{
				if(i+j==row+1)
					System.out.print("#");
				else 
					System.out.print("*");				
			}
			System.out.println();
		}
	}

}

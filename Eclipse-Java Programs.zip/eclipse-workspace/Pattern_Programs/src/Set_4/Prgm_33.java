package Set_4;

import java.util.Scanner;
//1010101
//01010
//101
//0

public class Prgm_33 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int row=sc.nextInt();
		for(int i=row;i>=1;i--)
		{
			for(int j=1;j<=(i*2)-1;j++)
			{
				System.out.print((i+j)%2);
			}
			System.out.println();
		}
		
	}
}

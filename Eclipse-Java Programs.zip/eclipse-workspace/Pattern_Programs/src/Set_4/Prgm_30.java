package Set_4;

import java.util.Scanner;
//1
//3 2
//6 5 4
//10 9 8 7
//15 14 13 12 11
public class Prgm_30 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int row=sc.nextInt();
		int num=0;
		for(int i=1;i<=row;i++)
		{
			num=num+i;
			int a=num;
			for(int j=1;j<=i;j++)
			{
					System.out.print(a--);
			}
			
			System.out.println();
		}
	}
}

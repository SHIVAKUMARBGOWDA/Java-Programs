package Set_4;

import java.util.Scanner;
//****
//***
//**
//*
public class Prgm_5 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int row=sc.nextInt();
		for(int i=row;i>0;i--)
		{
			for(int j=0;j<i;j++)
			{
				System.out.print("*"); //Reverse Triangle
			}
			System.out.println();
		}	
		
	}
}

package Set_4;

import java.util.Scanner;
//a
//b1
//c2d
//e3f4
//g5h6i
public class Prgm_28 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int row=sc.nextInt();
		char c='a';
		int num=1;
		for(int i=1;i<=row;i++)
		{
			
			for(int j=1;j<=i;j++)
			{
				if(j%2==1)
					System.out.print(c++);
				else
					System.out.print(num++);
			}
			System.out.println();
		}		
	}
}

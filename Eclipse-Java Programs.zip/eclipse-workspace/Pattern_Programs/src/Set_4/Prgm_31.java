package Set_4;

import java.util.Scanner;
//10101
//01010
//10101
//01010
//10101

public class Prgm_31 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int row=sc.nextInt();
		for(int i=1;i<=row;i++)
		{			
			for(int j=1;j<=row;j++)
			{
					System.out.print((i+j+1)%2);			
			}			
			System.out.println();
		}
	}
}


//SOP((i+j)%2) === 0101              SOP((i+j+1)%2) === 1010
//			       1010                                 0101
//			       0101                                 1010
//			       1010                                 0101
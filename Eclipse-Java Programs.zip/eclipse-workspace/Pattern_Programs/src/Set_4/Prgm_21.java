package Set_4;

import java.util.Scanner;
//1234
//abcd
//5678
//efgh

public class Prgm_21 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int row=sc.nextInt();
		char c='a';
		int num=1;
		for(int i=1;i<=row;i++)
		{
			for(int j=1;j<=row;j++)
			{
				if(i%2==1)
				{
					System.out.print(num);
					num++;				
				}
				else
				{
					System.out.print(c);
					c++;
				}
			}
			System.out.println();
		}		
	}
}

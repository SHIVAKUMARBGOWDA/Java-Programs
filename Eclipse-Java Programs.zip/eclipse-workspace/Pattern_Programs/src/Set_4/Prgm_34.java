package Set_4;

import java.util.Scanner;
//1 
//4 9 
//16 25 36 
//49 64 81 100 

public class Prgm_34 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int row=sc.nextInt();
		int num=1;
		for(int i=1;i<=row;i++)
		{
			for(int j=1;j<=i;j++)
			{		
				System.out.print(num*num + " ");
				num++;
			}
			System.out.println();
		}		
	}
}

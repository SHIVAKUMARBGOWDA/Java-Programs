package Dynamic_Package;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class ReadFromUser_InsertingValues 
{
	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		Scanner sc=new Scanner(System.in);
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/school","root","root");
		
		PreparedStatement ps=con.prepareStatement("insert into student values(?,?)");
		
		System.out.println("Enter the id?");
		int id=sc.nextInt();
		System.out.println("Enter the name?");
		String name=sc.next();
		
		ps.setInt(1, id);
		ps.setString(2, name);
		
		ps.execute();
		
		con.close();		
	}
}

package Dynamic_Package;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteFromUser 
{
	public static void main(String[] args) throws ClassNotFoundException, SQLException
	{
		Scanner sc=new Scanner(System.in);
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/school","root","root");
		
		PreparedStatement ps=con.prepareStatement("delete from student where id=?");
		
		System.out.println("Enter the id to delete?");
		int id=sc.nextInt();
		ps.setInt(1, id);
		ps.execute();
		
		con.close();
		
	}

}

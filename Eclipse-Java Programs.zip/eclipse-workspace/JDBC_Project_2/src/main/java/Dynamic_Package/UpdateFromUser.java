package Dynamic_Package;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateFromUser 
{
	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		Scanner sc=new Scanner(System.in);
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/school","root","root");
		
		PreparedStatement ps=con.prepareStatement("update student set name=? where id=?");
		
		System.out.println("Enter id for which you want to update name");
		int id=sc.nextInt();
		
		System.out.println("Enter the new name to update");
		String name=sc.next();
		
		ps.setInt(2, id);
		ps.setString(1, name);
		
		ps.execute();
		
		con.close();
	}
}

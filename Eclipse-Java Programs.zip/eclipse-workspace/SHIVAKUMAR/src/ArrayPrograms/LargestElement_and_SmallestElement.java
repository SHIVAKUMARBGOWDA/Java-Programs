package ArrayPrograms;

import java.util.Scanner;

public class LargestElement_and_SmallestElement
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int size=sc.nextInt();
		int a[]=new int[size];
		int max=a[0];
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		for(int i=0;i<a.length;i++)
		{
			if(max<a[i])   		//largest element
			{
				max=a[i];
			}	
		}
		System.out.println("Largest Element is: "+max);
		System.out.println();
		int min=a[0];
		for(int i=0;i<a.length;i++)
		{
			if(min>a[i])   		//smallest element
			{
				min=a[i];
			}	
		}
		System.out.println("Smallest Element is: "+min);
	}

}

package ArrayPrograms;

public class Matching_Words 
{
	public static void main(String[] args) {
		String s="abc_abc_abc_abc_xyz_xyz_xyz_pqr_pqr";
		String[] s1=s.split("_");  
        int count=1;       
        for(int i=0;i<s1.length;i++)
        {
            for(int j=i+1;j<s1.length;j++)
            {
              if(s1[i].equals(s1[j]) &&s1[j]!="-1")
                {
                     s1[j]="-1";
                    count++; 
                }
            }   
            if(s1[i]!="-1")
            {
                System.out.println(s1[i]+" occurs "+count+" times");
                 s1[i]="-1";
            }
            count=1;	
}
}
}
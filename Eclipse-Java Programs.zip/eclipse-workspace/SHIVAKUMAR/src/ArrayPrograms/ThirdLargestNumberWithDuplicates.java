package ArrayPrograms;

import java.util.Scanner;

public class ThirdLargestNumberWithDuplicates 
{
	public static int third(int a[], int size)
	{
		int l,sl,tl;
		tl=l=sl=Integer.MIN_VALUE;
		for(int i=0;i<size;i++)
		{
			if(a[i]>l)
			{
				tl=sl;
				sl=l;
				l=a[i];
			}
			else if(a[i]>sl)
			{
				tl=sl;
				sl=a[i];
			}
			else if(a[i]>tl)
			{
				tl=a[i];
			}
		}
		return tl;
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int size=sc.nextInt();
		int a[]=new int[size];
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		int tn=third(a,size);
		System.out.println(tn);
	}

}

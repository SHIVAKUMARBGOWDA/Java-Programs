package Add;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Create
{
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bus","root","root");
		
		Statement st=con.createStatement();
		st.execute("create table bus(id integer,name varchar(20))");
		st.execute("insert into bus values(1,'Raj')");
		ResultSet rs=st.executeQuery("select * from bus");
		while(rs.next())
		{
			System.out.println(rs.getInt(1)+" "+rs.getString(2));
		}
		con.close();
	}

}

package Set_3;

import java.util.Scanner;

public class Perfect_Squares_Range 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the range of m:");
		int m=sc.nextInt();
		System.out.println("Enter the range of n:");
		int n=sc.nextInt();
		for(int i=m+1;i<n;i++)
		{
			int num=i;
			for(int j=1;j<=num;j++)
			{
				int sqr=j*j;
				if(sqr==num)
				{
					System.out.println(j+"*"+j+"="+num);
					break;
				}
			}
		}		
	}
}

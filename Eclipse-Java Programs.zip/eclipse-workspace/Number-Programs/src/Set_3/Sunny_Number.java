package Set_3;

import java.util.Scanner;
//Sunny Number: Perfect square before number is a Sunny number
// Ex: (2*2)=4 is the perfect square before number is 3

//1.Take the input from the user
//2.Add +1 to the input
//3.Set the range from 1 to what we got the value from step-2
//4.From the range square every number & compare with the original number
//5.If u compared successfully print the sunny number

public class Sunny_Number 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Number");
		int num=sc.nextInt();
		int num1=num+1;
		boolean flag=false;
		for(int i=1;i<=num1;i++)
		{
			int sqr=i*i;
			if(sqr==num1)
			{
				flag=true;
				break;
			}
		}
		if(flag)
			System.out.println("Given Number is Sunny Number");
		else
			System.out.println("Not a Sunny Number");
		
	}
}

package Set_3;

import java.util.Scanner;

public class ArmStrongNumber_Range 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Range of m:");
		int m=sc.nextInt();
		System.out.println("Enter the Range of n:");
		int n=sc.nextInt();
		for(int i=m+1;i<n;i++)
		{
			int num=i;
			int num1=i;
			int count=0;
			while(num>0)
			{
				count++;
				num=num/10;
			}
			int sum=0;
			while(num1>0)
			{
				int rem=num1%10;
				int pow=1;
				for(int j=1;j<=count;j++)
				{
					pow =pow*rem;
				}
				sum=sum+pow;
				num1=num1/10;
			}
			if(sum==i)
				System.out.println(i);
		}		
	}
}

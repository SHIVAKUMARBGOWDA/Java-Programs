package Set_3;

import java.util.Scanner;

public class Neon_Number 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Number");
		int num=sc.nextInt();
		int sqr=num*num;
		int sum=0;
		while(sqr!=0)
		{
			int last=sqr%10;
			sum=sum+last;
			sqr/=10;
		}
		if(sum==num)
			System.out.println("Neon Number");
		else
			System.out.println("Not a Neon Number");
	}

}


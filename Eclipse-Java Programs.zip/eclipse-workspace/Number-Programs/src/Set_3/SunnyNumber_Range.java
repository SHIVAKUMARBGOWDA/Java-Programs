package Set_3;

import java.util.Scanner;

public class SunnyNumber_Range 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int m=sc.nextInt();
		int n=sc.nextInt();
		for(int i=m;i<n;i++)
		{
			int num=i;		
			int num1=num+1;
			boolean flag=false;
			for(int j=1;j<=num1;j++)
			{
				int sqr=j*j;
				if(sqr==num1)
				{
					flag=true;
					break;
				}
			}
			if(flag)
				System.out.print(num+" ");
		}
	}
}




package StringPrgms;

import java.util.Scanner;

public class Remove_Vowels_In_String 
{
	public static String RemoveVowels(String s)
	{
		String s1="";
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)!='a' &&s.charAt(i)!='e'&&s.charAt(i)!='i'&&s.charAt(i)!='o'
				&&s.charAt(i)!='u')
			{
				s1=s1+s.charAt(i);
			}
		}
		return s1;		
	}
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String");
		String s=sc.nextLine();
		String str=RemoveVowels(s);
		System.out.println(str);
	}

}

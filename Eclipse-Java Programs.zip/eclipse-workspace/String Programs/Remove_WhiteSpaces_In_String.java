package StringPrgms;

import java.util.Scanner;

public class Remove_WhiteSpaces_In_String
{
	public static String whiteSpaces(String s)
	{
		String s1="";
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)!=' ')
				s1=s1+s.charAt(i);
		}
		return s1;
	}
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String");
		String s=sc.nextLine();
			String str=whiteSpaces(s);
			System.out.println(str);
	}

}

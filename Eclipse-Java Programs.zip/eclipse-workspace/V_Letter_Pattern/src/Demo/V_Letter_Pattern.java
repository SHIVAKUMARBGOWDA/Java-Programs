package Demo;

import java.util.Scanner;

public class V_Letter_Pattern 
{
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 1st number in the series: ");
		int n1=sc.nextInt();
		System.out.println("Enter 2nd number in the series: ");
		int n2=sc.nextInt();
		
		System.out.println();
		System.out.println("Enter the row size");
		int row=sc.nextInt();
		
		for(int j=1;j<=row;j++)
		{
			for(int k=1;k<=row;k++)
			{
				if (j<=row/2+1) 
				{
					if(j==k ||j+k==row+1)
					{
						
						int n3=n1+n2;
						System.out.print(n1);
						n1=n2;
						n2=n3;
					}
					else
						System.out.print(" ");
				}
			
			}
			System.out.println();
		}

}
	}


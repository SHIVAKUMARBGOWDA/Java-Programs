package com.jsp;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(value="prototype")
public class Employe //By Constructor method
{
	String name;
	int age;
	
	public Employe(@Value(value="Rajesh") String name, @Value(value="23") int age) {
		super();
		this.name = name;
		this.age = age;
	}
	
	public void display()
	{
		System.out.println(name+" "+age );
	}
}

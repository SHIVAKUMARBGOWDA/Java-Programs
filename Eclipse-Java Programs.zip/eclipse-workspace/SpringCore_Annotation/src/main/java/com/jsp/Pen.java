package com.jsp;

import org.springframework.stereotype.Component;

@Component
public class Pen 
{
	public void test()
	{
		System.out.println("Pen is writting......");
	}
}

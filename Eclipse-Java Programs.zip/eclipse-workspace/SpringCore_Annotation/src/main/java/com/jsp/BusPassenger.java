package com.jsp;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class BusPassenger
{
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext ac=new AnnotationConfigApplicationContext(Config.class);
		
	Bus b=(Bus)ac.getBean("bus");
	
	b.getPassenger().add();
	}

}

package com.jsp;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class EmployeDriver
{
	public static void main(String[] args) {

	AnnotationConfigApplicationContext ac=new AnnotationConfigApplicationContext(Config.class);
	
	Employe e=(Employe)ac.getBean("employe");
	e.display();
	System.out.println(e);
	
	Employe e1=(Employe)ac.getBean("employe");
	System.out.println(e1);

	}
}

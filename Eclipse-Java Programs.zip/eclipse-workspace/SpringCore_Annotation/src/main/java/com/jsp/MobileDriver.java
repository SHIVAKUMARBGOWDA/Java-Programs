package com.jsp;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MobileDriver 
{
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext ac=new AnnotationConfigApplicationContext(Config.class);
		
		Mobile m=(Mobile)ac.getBean("mobile");
		
		m.getSim().showMethod();
	}

}

package com.jsp;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Person
{
	@Value(value="Raj")
	String name;
	@Value(value="23")
	int age;
	
	public void display()
	{
		System.out.println(name+" "+age);
	}
}

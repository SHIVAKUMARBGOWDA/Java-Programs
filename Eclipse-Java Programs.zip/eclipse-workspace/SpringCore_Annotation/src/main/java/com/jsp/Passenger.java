package com.jsp;

import org.springframework.stereotype.Component;

@Component
public class Passenger
{
	String name;
	
	public void add()
	{
		System.out.println("Passenger added....");
	}
	
	

}

package com.jsp;

import org.springframework.stereotype.Component;

@Component
public class Sim 
{
	String provider;

	public void showMethod()
	{
		System.out.println("Sim is working......");
	}
}

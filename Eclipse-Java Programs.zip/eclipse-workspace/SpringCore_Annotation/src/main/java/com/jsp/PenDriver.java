package com.jsp;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class PenDriver 
{
	public static void main(String[] args) 
	{
		AnnotationConfigApplicationContext ac=new AnnotationConfigApplicationContext(Config.class);
		//acac shortcut
		Pen p=(Pen)ac.getBean("pen");
		p.test();
		
	}

}

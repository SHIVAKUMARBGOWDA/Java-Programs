package Demo;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Installer 
{
	public static void main(String[] args) {
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("shiva");
		System.out.println(factory);
	}
}

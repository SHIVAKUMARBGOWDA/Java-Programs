package Demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class UserData 
{
	public static void main(String[] args) {
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("shiva");
		
		EntityManager manager=factory.createEntityManager();
		
		EntityTransaction transaction=manager.getTransaction();
		
		User u=new User();
		u.setId(1);;
		u.setName("SHIVAKUMAR.B");
		u.setEmail("shivuvbs383@gmail.com");
		u.setPhone_number(9110664616l);
		
		transaction.begin();
		manager.persist(u);
		transaction.commit();
		
	}

}

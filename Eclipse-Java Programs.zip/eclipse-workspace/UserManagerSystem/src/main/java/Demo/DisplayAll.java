package Demo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class DisplayAll
{
	public static void main(String[] args) {
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("shiva");
		EntityManager manager=factory.createEntityManager();
		
		//Creating a Query
		Query q=manager.createQuery("select u from User u");
		
		//Execute query and get the result
		List<User> lt=q.getResultList();
		
		//Displaying from List using for each loop
		for(User u :lt)
		{	
			System.out.println(u.getId()+" "+u.getName()+" "+u.getEmail()+" "+u.getPhone_number());
		}
	}
}

package Demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class DeleteUser
{
	public static void main(String[] args) {
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("shiva");
		
		EntityManager manager=factory.createEntityManager();
		
		EntityTransaction transaction=manager.getTransaction();
		
		//Search if object is present or not
		User u=manager.find(User.class, 2);
		
		if(u!=null)
		{
			transaction.begin();
			manager.remove(u);
			
			transaction.commit();
		}
		else
			System.out.println("ID is not found.....");
	}

}

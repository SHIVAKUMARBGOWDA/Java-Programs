package Demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class FindUser 
{
	public static void main(String[] args) 
	{	
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("shiva");
		
		EntityManager manager=factory.createEntityManager();
		
		User u=manager.find(User.class, 1);
		
		System.out.println();
		if(u!=null)
			System.out.println(u.getId()+" "+u.getName()+" "+u.getEmail()+" "+u.getPhone_number());
		else
			System.out.println("Id not found........");
	}
	
}

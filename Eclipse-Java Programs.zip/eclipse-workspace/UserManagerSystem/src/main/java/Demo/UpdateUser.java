package Demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class UpdateUser 
{
	public static void main(String[] args) {
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("shiva");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transaction=manager.getTransaction();
		
		//Fetching object from database
		User u=manager.find(User.class, 1);
		//If object is present
		if(u!=null)
		{
			//Set the values
			u.setName("Shivu");
			u.setPhone_number(9738541895l);
			
			//Merge or update the new object into database
			transaction.begin();
			manager.merge(u);
			transaction.commit();
		}
		else
			System.out.println("Id is not found");
	}
}

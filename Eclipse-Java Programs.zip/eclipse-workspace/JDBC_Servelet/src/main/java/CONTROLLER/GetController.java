package CONTROLLER;

import java.io.IOException;
import java.io.PrintWriter;

import javax.jws.soap.SOAPBinding.Use;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.User_DAO;
import DTO.User;

@WebServlet("/get")
public class GetController extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		String id=req.getParameter("myid");
		
		User_DAO dao=new User_DAO();
		
		try
		{
			User u=dao.getUser(Integer.parseInt(id));
			PrintWriter pw=resp.getWriter();
			resp.setContentType("text/html");
			
			pw.print(u.getId()+" ");
			pw.print(u.getName()+" ");
			pw.print(u.getAge()+" ");
			pw.print(u.getAddress());
			
		}
		catch(Exception e)
		{	
			//For Check the Errors
			e.printStackTrace();
			System.out.println("Enter valid Input");
		}		
	}
}

package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import DTO.User;

public class User_DAO
{
	public Connection getConnection() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/user","root","root");
		return con;
	}
	
	public void insertValues(User u) throws ClassNotFoundException, SQLException
	{
		PreparedStatement ps=getConnection().prepareStatement("insert into userdb values(?,?,?,?)");
		
		//fetching the data from user object
		int id=u.getId();
		String name=u.getName();
		int age=u.getAge();
		String address=u.getAddress();
		
		//set values to query
		ps.setInt(1, id);
		ps.setString(2, name);
		ps.setInt(3, age);
		ps.setString(4, address);
		
		//execute the query
		ps.execute();
	}

	public User getUser(int id) throws ClassNotFoundException, SQLException
	{
		PreparedStatement ps=getConnection().prepareStatement("select * from userdb where id=?");
		ps.setInt(1, id);
		
		ResultSet rs=ps.executeQuery();
		
		User u=new User();
		while(rs.next())
		{
			u.setId(rs.getInt(1));
			u.setName(rs.getString(2));
			u.setAge(rs.getInt(3));
			u.setAddress(rs.getString(4));
		}
		return u;
		
	}
}

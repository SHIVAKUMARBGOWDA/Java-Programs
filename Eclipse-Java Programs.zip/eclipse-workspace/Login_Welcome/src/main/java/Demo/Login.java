package Demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/post")
public class Login extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		resp.setContentType("text/html");
		String name=req.getParameter("myname");
		String mail=req.getParameter("email");
		String location=req.getParameter("location");
		
		PrintWriter pw=resp.getWriter();
		
		pw.print("<h1 style=backgroud-color:lightgreen;color:red>Welcome....."+name+" </h1>");
		pw.println("Name= "+name+"<br>");
		pw.println("Email Id= "+mail+"<br>");
		pw.println("Location= "+location+"<br>");
		
		if(name.equals(name))
		{
			System.out.println(name);
			System.out.println(mail);
			System.out.println(location);
		}
		else
		{
			System.out.println("Name not found....!");
		}
	}
}
